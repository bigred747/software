# Install in WordPress

Use **luxe-affiliate-product-scout.zip**. That filename matches the plugin folder WordPress expects.

## WordPress admin (Hostinger / wp-admin)

1. Download [luxe-affiliate-product-scout.zip](https://github.com/bigred747/software/raw/refs/heads/cursor/product-scout-integrity-7e00/luxe-affiliate-product-scout.zip) (use this raw link, not the GitHub preview page).
2. In WordPress go to **Plugins → Add Plugin → Upload Plugin**.
3. Choose `luxe-affiliate-product-scout.zip` → **Install Now**.
4. If WordPress says the plugin is already installed, click **Replace current with uploaded**.
5. Click **Activate Plugin** if it is not already active.
6. Open **Luxe Product Scout** in the left admin menu.
7. Click **Repair ALL Catalog Data + Recalculate**, then **Run Full Catalog Audit**.
8. Purge LiteSpeed once.

WooCommerce must already be active. This plugin does not replace WooCommerce, Rank Math, Score Repair, or Mission Control.

## What WordPress should show after upload

- Plugins list: **Luxe Affiliate Product Scout** version **5.6.5**
- Admin menu: **Luxe Product Scout**
