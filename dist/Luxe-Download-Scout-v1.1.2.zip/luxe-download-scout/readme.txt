=== Luxe Download Scout ===
Contributors: luxetrendsetters
Tags: woocommerce, affiliate products, wzone, catalog
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later

Shows which WZone products are safe to download using the same 95-100 catalog gates as Product Scout. Never imports.

== Description ==

Paste a WZone result list. Download Scout keeps a row only when it has a supported brand, a real price, and no renewed, used, refurbished, unknown-brand, accessory, or duplicate-model problem.

Version 1.1.0 can add the 100-score rows to Products as unpublished drafts in the matching category. It does not publish them, and it does not invent an ASIN, image, or affiliate URL. A 95-score row is shown and left out of Products.

== Installation ==

1. Activate Luxe Affiliate Product Scout 5.6.8 first.
2. Upload `luxe-download-scout.zip` in Plugins → Add Plugin.
3. Open Luxe Download Scout and paste the WZone list.

== Changelog ==

= 1.1.2 =
* Read Sony85 and Samsung50 titles. Recognize TV model codes. Keep renewed sets and wall mounts out. Google TV still files under TVs.

= 1.1.1 =
* Read glued AppleWatch and GooglePixel titles as Apple and Google. Keep watch bands and renewed watches out. 42mm and 46mm stay separate.

= 1.1.0 =
* Add only 100-score rows to Products as unpublished drafts in the matching category.

= 1.0.0 =
* First release. Admin-only WZone download decisions for the 95-100 catalog gates.
