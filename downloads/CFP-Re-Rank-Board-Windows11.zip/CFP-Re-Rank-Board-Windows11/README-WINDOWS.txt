CFP Re-Rank Board for Windows 11 + iPhone
=======================================

Artex-safe local desk. Fast. One-tap logo launch.

WINDOWS
1. Download and open the zip
2. Double-click "Put Logo on Desktop.bat"
   (it copies the board into Documents\CFP Re-Rank Board and
    puts "CFP Re-Rank Board" on your Desktop)
3. Anytime after that: click the Desktop icon
4. Leave the black window open while you use the board

If Windows says a shortcut "doesn't exist", delete the old Desktop
icon and run Put Logo on Desktop.bat again from the zip folder.

IPHONE
1. Open the board in Safari (published app or your PC address on Wi-Fi)
2. Tap Share → Add to Home Screen
3. Tap the CFP logo on your Home Screen anytime

Safety
------
- Blocks Artex / foreign-bot folder paths (same rule as Paper Trader)
- Blocks temporary zip folds
- Serves only files inside the app folder
- Adds CSP / nosniff / frame deny headers
- Rankings stay in the browser on that device

Buttons on the ranking sheet
----------------------------
Setup roster / committee / first board / 25-factor
Update this week · Start next week · Download CSV
