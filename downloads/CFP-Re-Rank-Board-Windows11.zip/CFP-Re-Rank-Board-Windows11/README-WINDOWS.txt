CFP Re-Rank Board for Windows 11 + iPhone
=======================================

Artex-safe local desk. Fast. One-tap logo launch.

WINDOWS — easiest
1. Download INSTALL-CFP-Re-Rank.bat from the downloads folder
2. Double-click it (it fetches the latest board and makes the Desktop logo)

WINDOWS — from the zip
1. Right-click CFP-Re-Rank-Board-Windows11.zip → Extract All
2. Open the extracted folder (not inside the zip window)
3. Double-click "Put Logo on Desktop.bat"
4. Desktop name: CFP Re-Rank Board

Do NOT just open the zip and double-click files inside it.
If you did that, use INSTALL-CFP-Re-Rank.bat instead.

IPHONE
1. Open the board in Safari (published app or your PC address on Wi-Fi)
2. Tap Share → Add to Home Screen
3. Tap the CFP logo on your Home Screen anytime

Safety
------
- Blocks Artex / foreign-bot folder paths (same rule as Paper Trader)
- Blocks temporary zip folds
- Serves only files inside the app folder
- Adds CSP / nosniff / frame deny headers
- Rankings stay in the browser on that device

Buttons on the ranking sheet
----------------------------
Setup roster / committee / first board / 25-factor
Update this week · Start next week · Download CSV
