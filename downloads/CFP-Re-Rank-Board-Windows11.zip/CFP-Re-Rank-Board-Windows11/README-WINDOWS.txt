CFP Re-Rank Board for Windows 11
================================

Artex-safe local desk. Fast. Local only. No install.

1. Extract to Documents\CFP Re-Rank Board
   Do NOT leave it in an Artex folder or a temporary zip fold.
2. Double-click "Start CFP Re-Rank.bat"
3. Browser opens http://127.0.0.1:3847
4. Leave the black window open while you use it

Safety
------
- Blocks Artex / foreign-bot folder paths (same rule as Paper Trader)
- Blocks temporary zip folds
- Serves only files inside the app folder
- Adds CSP / nosniff / frame deny headers
- Your rankings stay in this browser on this PC

Buttons
-------
Setup roster / committee / first board / 25-factor board
Update this week · Start next week · View 1-25 · Download CSV
Year menu works for 2026 and every season after
