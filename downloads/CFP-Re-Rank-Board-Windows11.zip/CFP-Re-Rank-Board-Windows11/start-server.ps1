$ErrorActionPreference = "Stop"
$port = 3847
$desk = $PSScriptRoot
$root = Join-Path $desk "app"
$url = "http://127.0.0.1:$port/"

function Normalize-PathText([string]$PathValue) {
  return ($PathValue -replace "/", "\").ToLowerInvariant()
}

function Test-TempZipExtract([string]$PathValue) {
  $text = Normalize-PathText $PathValue
  return ($text -like "*\temp\*") -and ($text -like "*.zip.*")
}

function Test-ForeignPath([string]$PathValue) {
  $text = Normalize-PathText $PathValue
  $parts = $text -split "[\\/]" | Where-Object { $_ }
  $markers = @("artex", "art-ex", "art_ex", "art ex")
  foreach ($part in $parts) {
    $cleaned = ($part -replace "[_-]", " ")
    $compact = ($part -replace "[_\- ]", "")
    foreach ($marker in $markers) {
      $token = ($marker -replace " ", "")
      if ($marker -eq $cleaned -or $marker -eq $part -or $token -eq $compact) { return $true }
      if ($token.Length -ge 5 -and $compact.Contains($token)) { return $true }
    }
  }
  return $false
}

foreach ($probe in @($desk, $root, $PSCommandPath)) {
  if (Test-TempZipExtract $probe) {
    Write-Host "Blocked: temporary zip fold."
    Write-Host "Extract to Documents\CFP Re-Rank Board, then run Start CFP Re-Rank.bat there."
    exit 1
  }
  if (Test-ForeignPath $probe) {
    Write-Host "Blocked: Artex / foreign-bot path."
    Write-Host "Keep this desk in Documents\CFP Re-Rank Board only. Artex cannot share these files."
    exit 1
  }
}

if (-not (Test-Path $root)) {
  Write-Host "Missing app folder next to this script."
  exit 1
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)
try {
  $listener.Start()
} catch {
  Write-Host "Port $port is busy. Close the other CFP Re-Rank window and try again."
  exit 1
}

Start-Process $url | Out-Null
Write-Host "Foreign bots kept out: Artex cannot share this desk."
Write-Host "Serving $root"
Write-Host "Open $url"
Write-Host "Press Ctrl+C or close this window to stop."

$mime = @{
  ".html" = "text/html; charset=utf-8"
  ".js"   = "text/javascript; charset=utf-8"
  ".css"  = "text/css; charset=utf-8"
  ".csv"  = "text/csv; charset=utf-8"
  ".svg"  = "image/svg+xml"
  ".png"  = "image/png"
  ".ico"  = "image/x-icon"
  ".json" = "application/json"
  ".map"  = "application/json"
  ".txt"  = "text/plain; charset=utf-8"
  ".webp" = "image/webp"
  ".zip"  = "application/zip"
}
$csp = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com data:; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; object-src 'none'; frame-ancestors 'none'"

while ($listener.IsListening) {
  $context = $listener.GetContext()
  $request = $context.Request
  $response = $context.Response
  try {
    if ($request.HttpMethod -ne "GET" -and $request.HttpMethod -ne "HEAD") {
      $response.StatusCode = 405
      $response.Close()
      continue
    }
    $rel = [Uri]::UnescapeDataString($request.Url.AbsolutePath.TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($rel)) { $rel = "index.html" }
    if ($rel.Contains("..")) {
      $response.StatusCode = 403
      $response.Close()
      continue
    }
    $rel = $rel -replace "/", "\"
    $path = [System.IO.Path]::GetFullPath((Join-Path $root $rel))
    $rootFull = [System.IO.Path]::GetFullPath($root)
    if (-not $path.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
      $response.StatusCode = 403
      $response.Close()
      continue
    }
    if ((Test-Path $path -PathType Container)) {
      $path = Join-Path $path "index.html"
    }
    if (-not (Test-Path $path -PathType Leaf)) {
      $response.StatusCode = 404
      $bytes = [System.Text.Encoding]::UTF8.GetBytes("Not found")
      $response.ContentType = "text/plain; charset=utf-8"
      $response.OutputStream.Write($bytes, 0, $bytes.Length)
      $response.Close()
      continue
    }
    $ext = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
    $response.Headers.Add("X-Content-Type-Options", "nosniff")
    $response.Headers.Add("Referrer-Policy", "no-referrer")
    $response.Headers.Add("X-Frame-Options", "DENY")
    $response.Headers.Add("Content-Security-Policy", $csp)
    $response.ContentType = $(if ($mime.ContainsKey($ext)) { $mime[$ext] } else { "application/octet-stream" })
    if ($request.HttpMethod -eq "HEAD") {
      $response.ContentLength64 = (Get-Item -LiteralPath $path).Length
      $response.Close()
      continue
    }
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $response.ContentLength64 = $bytes.Length
    $response.OutputStream.Write($bytes, 0, $bytes.Length)
  } catch {
    try { $response.StatusCode = 500 } catch {}
  } finally {
    try { $response.OutputStream.Close() } catch {}
    try { $response.Close() } catch {}
  }
}
