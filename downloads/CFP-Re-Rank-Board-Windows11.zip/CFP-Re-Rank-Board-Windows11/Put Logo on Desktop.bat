@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CFP Re-Rank Board setup

echo.
echo  CFP Re-Rank Board setup
echo.

if not exist "%~dp0cfp-logo.ico" goto NEED_EXTRACT
if not exist "%~dp0Start CFP Re-Rank.bat" goto NEED_EXTRACT
if not exist "%~dp0app\index.html" goto NEED_EXTRACT
if not exist "%~dp0start-server.ps1" goto NEED_EXTRACT

set "HOME=%USERPROFILE%\Documents\CFP Re-Rank Board"
echo  Copying files to:
echo  %HOME%
echo.

if not exist "%HOME%" mkdir "%HOME%"
xcopy "%~dp0*" "%HOME%\" /E /I /Y /Q >nul
if errorlevel 1 (
  echo  Copy failed. Close other windows and try again.
  pause
  exit /b 1
)

REM Remove junk copies if present
if exist "%HOME%\app\CFP-Re-Rank-Board-Windows11.zip" del /q "%HOME%\app\CFP-Re-Rank-Board-Windows11.zip"
if exist "%HOME%\CFP-Re-Rank-Board-Windows11.zip" del /q "%HOME%\CFP-Re-Rank-Board-Windows11.zip"

set "DESKTOP=%USERPROFILE%\Desktop"
if exist "%USERPROFILE%\OneDrive\Desktop" set "DESKTOP=%USERPROFILE%\OneDrive\Desktop"
if defined OneDrive if exist "%OneDrive%\Desktop" set "DESKTOP=%OneDrive%\Desktop"

set "LNK=%DESKTOP%\CFP Re-Rank Board.lnk"
if exist "%DESKTOP%\CFP Re-Rank.lnk" del /q "%DESKTOP%\CFP Re-Rank.lnk"

echo  Creating Desktop shortcut...
> "%TEMP%\cfp-shortcut.vbs" echo Set sh = CreateObject("WScript.Shell")
>>"%TEMP%\cfp-shortcut.vbs" echo Set sc = sh.CreateShortcut("%LNK%")
>>"%TEMP%\cfp-shortcut.vbs" echo sc.TargetPath = "%HOME%\Start CFP Re-Rank.bat"
>>"%TEMP%\cfp-shortcut.vbs" echo sc.WorkingDirectory = "%HOME%"
>>"%TEMP%\cfp-shortcut.vbs" echo sc.IconLocation = "%HOME%\cfp-logo.ico,0"
>>"%TEMP%\cfp-shortcut.vbs" echo sc.Description = "CFP Re-Rank Board"
>>"%TEMP%\cfp-shortcut.vbs" echo sc.Save

cscript //nologo "%TEMP%\cfp-shortcut.vbs"
del /q "%TEMP%\cfp-shortcut.vbs" >nul 2>&1

echo.
echo  Done.
echo  Desktop name: CFP Re-Rank Board
echo  Folder: %HOME%
echo.
echo  Double-click the Desktop icon anytime.
echo  If Bitdefender blocked the old installer, that was a false alarm
echo  on the download script. This setup does not download anything.
echo.
explorer /select,"%LNK%"
pause
exit /b 0

:NEED_EXTRACT
echo  These files are incomplete.
echo.
echo  Do this:
echo  1. Close this window
echo  2. Right-click CFP-Re-Rank-Board-Windows11.zip
echo  3. Choose Extract All
echo  4. Open the new folder that appears
echo  5. Double-click "Put Logo on Desktop.bat" there
echo.
echo  Do not run files from inside the zip window.
echo.
pause
exit /b 1
