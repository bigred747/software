@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-desktop-icon.ps1"
echo.
echo  Desktop logo ready. Double-click "CFP Re-Rank" on your Desktop anytime.
pause
