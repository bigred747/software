@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Put CFP logo on Desktop
echo.
echo  CFP Re-Rank Board installer
echo  Desktop name will be: CFP Re-Rank Board
echo.

REM If the full package is beside this bat, use it.
if exist "%~dp0install-desktop-icon.ps1" if exist "%~dp0cfp-logo.ico" if exist "%~dp0app\index.html" (
  echo  Found full package. Installing from this folder...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-desktop-icon.ps1"
  goto DONE
)

REM Opened from inside the zip = only this bat was unpacked. Download latest.
echo  Opened from inside the zip, or package files are missing.
echo  Downloading the latest complete board and putting the logo on Desktop...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$zipUrl='https://raw.githubusercontent.com/bigred747/software/main/downloads/CFP-Re-Rank-Board-Windows11.zip';" ^
  "$permanent=Join-Path $env:USERPROFILE 'Documents\CFP Re-Rank Board';" ^
  "$name='CFP Re-Rank Board';" ^
  "$zipPath=Join-Path $env:TEMP 'CFP-Re-Rank-Board-Windows11-latest.zip';" ^
  "$extract=Join-Path $env:TEMP ('CFP-Re-Rank-Extract-' + [guid]::NewGuid().ToString('N'));" ^
  "Write-Host 'Downloading...';" ^
  "Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing;" ^
  "if (Test-Path $extract) { Remove-Item -Recurse -Force $extract };" ^
  "Expand-Archive -LiteralPath $zipPath -DestinationPath $extract -Force;" ^
  "$root = Get-ChildItem -Path $extract -Recurse -Directory | Where-Object { (Test-Path (Join-Path $_.FullName 'Start CFP Re-Rank.bat')) -and (Test-Path (Join-Path $_.FullName 'cfp-logo.ico')) -and (Test-Path (Join-Path $_.FullName 'app')) } | Select-Object -First 1;" ^
  "if (-not $root) { throw 'Downloaded zip was incomplete.' };" ^
  "New-Item -ItemType Directory -Force -Path $permanent | Out-Null;" ^
  "Write-Host ('Installing to ' + $permanent);" ^
  "robocopy $root.FullName $permanent /E /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null;" ^
  "if ($LASTEXITCODE -ge 8) { throw ('Copy failed: ' + $LASTEXITCODE) };" ^
  "$nested=Join-Path $permanent 'app\CFP-Re-Rank-Board-Windows11.zip'; if (Test-Path $nested) { Remove-Item -Force $nested };" ^
  "$startBat=Join-Path $permanent 'Start CFP Re-Rank.bat';" ^
  "$icon=Join-Path $permanent 'cfp-logo.ico';" ^
  "$desktops=@(); foreach ($p in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Desktop'), (Join-Path $env:USERPROFILE 'OneDrive\Desktop'), (Join-Path $env:USERPROFILE 'OneDrive - Personal\Desktop'), $(if($env:OneDrive){Join-Path $env:OneDrive 'Desktop'}), [Environment]::GetFolderPath('CommonDesktopDirectory'))) { if ($p -and (Test-Path $p)) { $f=[IO.Path]::GetFullPath($p); if ($desktops -notcontains $f) { $desktops += $f } } };" ^
  "$shell=New-Object -ComObject WScript.Shell; $primary=$null;" ^
  "foreach ($d in $desktops) { foreach ($old in @('CFP Re-Rank.lnk','CFP Re-Rank Board.lnk')) { $op=Join-Path $d $old; if (Test-Path $op) { Remove-Item -Force $op -ErrorAction SilentlyContinue } }; $sp=Join-Path $d ($name + '.lnk'); $s=$shell.CreateShortcut($sp); $s.TargetPath=$startBat; $s.WorkingDirectory=$permanent; $s.IconLocation=($icon + ',0'); $s.Description='Open CFP Re-Rank Board'; $s.Save(); if (-not $primary) { $primary=$sp }; Write-Host ('Desktop icon: ' + $sp) };" ^
  "Start-Process explorer.exe -ArgumentList @('/select,' + $primary);" ^
  "Add-Type -AssemblyName PresentationFramework;" ^
  "[Windows.MessageBox]::Show(('Ready.' + [char]13 + [char]10 + [char]13 + [char]10 + 'Desktop name: ' + $name + [char]13 + [char]10 + [char]13 + [char]10 + 'Installed to:' + [char]13 + [char]10 + $permanent),'CFP Re-Rank Board') | Out-Null;" ^
  "Remove-Item -Recurse -Force $extract -ErrorAction SilentlyContinue; Remove-Item -Force $zipPath -ErrorAction SilentlyContinue"

if errorlevel 1 (
  echo.
  echo  Install failed. Try this instead:
  echo  1. Close this window
  echo  2. Right-click CFP-Re-Rank-Board-Windows11.zip
  echo  3. Click Extract All to Documents
  echo  4. Open the extracted folder
  echo  5. Double-click Put Logo on Desktop.bat
  echo.
)

:DONE
echo.
echo  Look for Desktop name: CFP Re-Rank Board
echo  Green circle logo, gold rim, white CFP letters.
echo.
pause
