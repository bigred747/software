@echo off
setlocal
cd /d "%~dp0"
title Put CFP logo on Desktop
echo.
echo  Putting "CFP Re-Rank Board" on every Desktop folder...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-desktop-icon.ps1"
echo.
echo  Look for:  CFP Re-Rank Board
echo  Green circle logo with gold rim and white CFP letters.
echo  This also opens File Explorer with the icon selected.
echo.
pause
