(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[`artex`,`art-ex`,`art_ex`,`art ex`];function t(e){return e.replace(/\//g,`\\`).toLowerCase()}function n(e){return e.replace(/[\\/_ -]/g,``)}function r(r){let i=t(r).split(`\\`).filter(Boolean);for(let t of i){let r=t.replace(/[_-]/g,` `),i=n(t);for(let a of e){let e=n(a);if(a===r||a===t||e===i||e.length>=5&&i.includes(e))return!0}}return!1}function i(r){let i=n(t(r));for(let t of e){let e=n(t);if(e&&i.includes(e))return t}return``}function a(e){let n=t(e);return n.includes(`\\temp\\`)&&n.includes(`.zip.`)}function o(e=s()){for(let t of e)if(t){if(r(t)){let e=i(t)||`artex`;return{name:`Foreign bots kept out`,ok:!1,hit:e,detail:`This path looks like ${e}. Move CFP Re-Rank to Documents\\CFP Re-Rank Board and reopen.`}}if(a(t))return{name:`Foreign bots kept out`,ok:!1,detail:`Running from a temporary zip fold. Extract to Documents\\CFP Re-Rank Board first.`}}return{name:`Foreign bots kept out`,ok:!0,detail:`Artex and other foreign-bot folders cannot share this desk's files.`}}function s(){return[typeof location<`u`?location.href:``,typeof location<`u`?location.pathname:``,typeof document<`u`?document.referrer:``].filter(Boolean)}function ee(e,t){return`${e}-${t}`}function c(e){let t=[e.committee,e.firstBoard,e.factors25].filter(e=>e>0);return t.length?t.reduce((e,t)=>e+t,0)/t.length:999}function l(e){return[...e].sort((e,t)=>{let n=c(e)-c(t);if(Math.abs(n)>1e-9)return n;let r=e.committee||999,i=t.committee||999;return r===i?e.team.localeCompare(t.team):r-i}).map((e,t)=>{let n=c(e);return{...e,combined:t+1,average:n,averageLabel:n>=900?`—`:n.toFixed(2),record:ee(e.wins,e.losses)}})}function u(e,t,n){return{id:`week-${t}-${n}-${Date.now()}`,weekNumber:t,label:`Week ${t} · ${n}`,gamesThrough:``,notes:`Cloned from ${e.label}. Log wins and losses, then refresh each setup board.`,teams:e.teams.map(e=>({...e})),results:[],updatedAt:new Date().toISOString(),setupDone:{roster:!0,committee:!1,firstBoard:!1,factors25:!1}}}function d(e,t,n,r=``){if(!t||!n||t===n)return e;let i=e.teams.map(e=>e.id===t?{...e,wins:e.wins+1}:e.id===n?{...e,losses:e.losses+1}:e);return{...e,teams:i,results:[{id:`game-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,winnerId:t,loserId:n,note:r.trim(),createdAt:new Date().toISOString()},...e.results],updatedAt:new Date().toISOString()}}function te(e,t){let n=e.results.find(e=>e.id===t);if(!n)return e;let r=e.teams.map(e=>e.id===n.winnerId?{...e,wins:Math.max(0,e.wins-1)}:e.id===n.loserId?{...e,losses:Math.max(0,e.losses-1)}:e);return{...e,teams:r,results:e.results.filter(e=>e.id!==t),updatedAt:new Date().toISOString()}}function ne(e){return[`Combined,Team,Record,Average,Committee,First board,25 factors`,...e.map(e=>`${e.combined},${f(e.team)},${e.record},${e.averageLabel},${e.committee},${e.firstBoard},${e.factors25}`)].join(`
`)+`
`}function f(e){return/[",\n]/.test(e)?`"${e.replaceAll(`"`,`""`)}"`:e}function p(e,t,n=`text/csv`){let r=new Blob([t],{type:n}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=e,a.click(),URL.revokeObjectURL(i)}function m(e,t){return e.teams.find(e=>e.id===t)?.team??t}var h=2026;function g(e,t,n,r,i,a){return{id:e.toLowerCase().replace(/[^a-z0-9]+/g,`-`),team:e,wins:t,losses:n,committee:r,firstBoard:i,factors25:a}}var re=[g(`Georgia`,9,1,1,1,1),g(`Texas`,8,2,5,2,2),g(`Notre Dame`,9,1,6,3,3),g(`Alabama`,8,2,3,6,5),g(`Utah`,10,0,2,7,6),g(`Miami`,9,1,7,9,4),g(`Tennessee`,8,2,9,5,8),g(`UCLA`,10,0,4,11,10),g(`Indiana`,9,1,8,10,9),g(`Oregon`,7,3,13,4,11),g(`Wake Forest`,9,1,11,13,7),g(`Ohio State`,7,3,14,8,12),g(`BYU`,8,2,10,12,13),g(`Texas Tech`,9,1,12,14,14),g(`Iowa`,8,2,15,16,15),g(`USC`,7,3,18,18,19),g(`Ole Miss`,6,4,25,15,16),g(`Arizona`,7,3,19,22,18),g(`South Carolina`,6,4,21,17,23),g(`Louisville`,7,3,23,21,17),g(`Boise State`,9,1,17,25,20),g(`Kentucky`,7,3,16,23,25),g(`Oklahoma`,6,4,22,20,22),g(`Florida`,6,4,24,19,21),g(`Houston`,7,3,20,24,24)],ie={roster:!0,committee:!0,firstBoard:!0,factors25:!0};function _(e=h){return{id:`week-12-${e}`,weekNumber:12,label:`Week 12 · ${e}`,gamesThrough:e===2026?`Nov. 15, 2026`:``,notes:e===2026?`Seeded from the Nov. 17 committee ranking plus the first board and 25-factor board.`:`Starter board for ${e}. Use the setup buttons, then update each week.`,teams:re.map(e=>({...e})),results:[],updatedAt:new Date().toISOString(),setupDone:{...ie}}}function v(e,t,n=[]){let r=n.length?n.map(e=>({...e,wins:0,losses:0,committee:0,firstBoard:0,factors25:0})):[];return{id:`week-${t}-${e}-${Date.now()}`,weekNumber:t,label:`Week ${t} · ${e}`,gamesThrough:``,notes:`New ${e} board. Run each setup button, then update weekly.`,teams:r,results:[],updatedAt:new Date().toISOString(),setupDone:{roster:r.length>0,committee:!1,firstBoard:!1,factors25:!1}}}var ae=[{num:1,input:`Win-loss record`,where:`All three`},{num:2,input:`Strength of schedule`,where:`Committee, first board, 25-factor board`},{num:3,input:`Head-to-head`,where:`All three`},{num:4,input:`Common opponents`,where:`Committee and the 25-factor board`},{num:5,input:`Missing players and coaches`,where:`Committee, and Oregon’s quarterback on the 25-factor board`},{num:6,input:`Offense, defense, and special teams`,where:`First board and the 25-factor board, from SP+`},{num:7,input:`SP+ overall`,where:`First board and the 25-factor board`},{num:8,input:`Sagarin rating`,where:`First board and the 25-factor board`},{num:9,input:`Results against the current top 10`,where:`First board and the 25-factor board`},{num:10,input:`Results against the current top 30`,where:`First board and the 25-factor board`},{num:11,input:`ESPN FPI`,where:`25-factor board`},{num:12,input:`FEI`,where:`25-factor board`},{num:13,input:`FPI, SP+, and FEI blend`,where:`25-factor board`},{num:14,input:`AP poll`,where:`25-factor board`},{num:15,input:`Coaches poll`,where:`25-factor board`},{num:16,input:`Record strength, résumé SP+`,where:`25-factor board`},{num:17,input:`Opponent-adjusted scoring margin`,where:`25-factor board`},{num:18,input:`Points scored per game`,where:`25-factor board`},{num:19,input:`Points allowed per game`,where:`25-factor board`},{num:20,input:`Sagarin recent form`,where:`25-factor board`},{num:21,input:`Sagarin strong-recent form`,where:`25-factor board`},{num:22,input:`Road scoring margin`,where:`25-factor board`},{num:23,input:`Game video`,where:`Committee only`},{num:24,input:`SportSource Analytics portal`,where:`Committee only`},{num:25,input:`Conference input`,where:`Committee only`},{num:26,input:`The committee’s final ballot`,where:`One of the three votes each week`}],oe=64,y=32,se=40,ce=200,b=64,le=160,ue=80,x=[`home`,`setup-roster`,`setup-committee`,`setup-first-board`,`setup-25-factor`,`update-week`,`combined`];function S(e,t=0,n=99){let r=Number(e);return Number.isFinite(r)?Math.min(n,Math.max(t,Math.trunc(r))):t}function C(e,t=b){return String(e??``).replace(/[\u0000-\u001F\u007F]/g,``).trim().slice(0,t)}function w(e){return C(e,ue).toLowerCase().replace(/[^a-z0-9-]+/g,`-`).replace(/^-+|-+$/g,``)||`team-${Date.now()}`}function de(e){let t=e??{};return{roster:!!t.roster,committee:!!t.committee,firstBoard:!!t.firstBoard,factors25:!!t.factors25}}function fe(e){if(!e||typeof e!=`object`)return null;let t=e,n=C(t.team,b);return n?{id:w(t.id||n),team:n,wins:S(t.wins,0,30),losses:S(t.losses,0,30),committee:S(t.committee,0,99),firstBoard:S(t.firstBoard,0,99),factors25:S(t.factors25,0,99)}:null}function pe(e){if(!e||typeof e!=`object`)return null;let t=e,n=w(t.winnerId),r=w(t.loserId);return!n||!r||n===r?null:{id:w(t.id||`game-${Date.now()}`),winnerId:n,loserId:r,note:C(t.note,le),createdAt:C(t.createdAt,40)||new Date().toISOString()}}function me(e){if(!e||typeof e!=`object`)return null;let t=e,n=Array.isArray(t.teams)?t.teams.map(fe).filter(e=>!!e).slice(0,oe):[],r=Array.isArray(t.results)?t.results.map(pe).filter(e=>!!e).slice(0,ce):[],i=S(t.weekNumber,1,30);return{id:w(t.id||`week-${i}`),weekNumber:i,label:C(t.label,48)||`Week ${i}`,gamesThrough:C(t.gamesThrough,64),notes:C(t.notes,240),teams:n,results:r,updatedAt:C(t.updatedAt,40)||new Date().toISOString(),setupDone:de(t.setupDone)}}function he(e){if(!e||typeof e!=`object`)return null;let t=e,n=S(t.year,2e3,2100),r=Array.isArray(t.weeks)?t.weeks.map(me).filter(e=>!!e).slice(0,y):[];if(!r.length)return null;let i=w(t.activeWeekId||r[0].id);return{year:n,weeks:r,activeWeekId:r.some(e=>e.id===i)?i:r[0].id}}function T(e,t){if(!e||typeof e!=`object`)return t;let n=e,r=Array.isArray(n.seasons)?n.seasons.map(he).filter(e=>!!e).slice(0,se):[];if(!r.length)return t;let i=S(n.activeYear,2e3,2100),a=x.includes(n.view)?n.view:`home`;return{seasons:r,activeYear:r.some(e=>e.year===i)?i:r[0].year,view:a}}function E(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#39;`)}var D=`cfp-rerank-board-v3`;function O(e,t=e===h){let n=t?_(e):v(e,1);return{year:e,weeks:[n],activeWeekId:n.id}}function k(){return{seasons:[O(h,!0)],activeYear:h,view:`combined`}}function A(){try{let e=localStorage.getItem(D)??localStorage.getItem(`cfp-rerank-board-v2`);if(!e||e.length>15e5)return k();let t=T(JSON.parse(e),k());return t.view===`home`&&(t.view=`combined`),t}catch{return k()}}function j(e){try{let t=T(e,k());localStorage.setItem(D,JSON.stringify(t))}catch{}}function M(e){return e.seasons.find(t=>t.year===e.activeYear)??e.seasons[0]}function N(e){let t=M(e);return t.weeks.find(e=>e.id===t.activeWeekId)??t.weeks[0]}function P(e,t){return{...e,view:t}}function F(e,t){let n=e.seasons.some(e=>e.year===t)?e.seasons:[...e.seasons,O(t,!1)];return{...e,seasons:n.sort((e,t)=>e.year-t.year),activeYear:t,view:`combined`}}function I(e,t){let n=e.seasons.map(n=>n.year===e.activeYear?{...n,weeks:n.weeks.map(e=>e.id===t.id?t:e),activeWeekId:t.id}:n);return{...e,seasons:n}}function L(e,t){let n=e.seasons.map(n=>n.year===e.activeYear?{...n,weeks:[...n.weeks,t].sort((e,t)=>e.weekNumber-t.weekNumber),activeWeekId:t.id}:n);return{...e,seasons:n,view:`update-week`}}function R(e,t){let n=e.seasons.map(n=>n.year===e.activeYear?{...n,activeWeekId:t}:n);return{...e,seasons:n}}function ge(e){let t=e.activeYear,n=t===2026?_(t):v(t,1),r=e.seasons.map(e=>e.year===t?{year:t,weeks:[n],activeWeekId:n.id}:e);return{...e,seasons:r,view:`combined`}}var z=document.querySelector(`#app`);if(!z)throw Error(`Missing #app root`);var B=A(),V=0,H=0,U=o();function W(e,t={}){B=e,t.immediate?(j(B),$()):(V||=requestAnimationFrame(()=>{V=0,j(B)}),_e())}function _e(){H||=requestAnimationFrame(()=>{H=0,$()})}function G(){return N(B)}function ve(){return M(B)}function ye(e,t=!0){let n=G();W(I(B,{...n,setupDone:{...n.setupDone,[e]:t},updatedAt:new Date().toISOString()}),{immediate:!0})}function K(e,t){let n=G();W(I(B,{...n,teams:n.teams.map(n=>n.id===e?{...n,...t}:n),updatedAt:new Date().toISOString()}))}function q(e){if(!(e instanceof HTMLElement))return null;let t=e.dataset.team,n=e.dataset.field||e.dataset.weekField||e.dataset.action;return t&&n?`${t}:${n}`:e instanceof HTMLInputElement&&e.name||e instanceof HTMLSelectElement&&e.name?`name:${e.name}`:n?`field:${n}`:null}function be(e,t){if(!e||!z)return;let n=z.querySelectorAll(`[data-team],[data-week-field],[name],select,input,button,a`);for(let r of n)if(q(r)===e){if(r.focus({preventScroll:!0}),r instanceof HTMLInputElement&&t!=null&&(r.type===`text`||r.type===`number`||r.type===`search`)){let e=Math.min(t,r.value.length);try{r.setSelectionRange(e,e)}catch{}}break}}function J(e){return G().setupDone[e]?`ready`:`todo`}function xe(){let e=new Set(B.seasons.map(e=>e.year));e.add(h),e.add(h+1),e.add(h+2);let t=Math.max(...e);return e.add(t+1),[...e].sort((e,t)=>e-t)}function Y(e){W(P(B,e),{immediate:!0})}function Se(e){return`
    <section class="sheet-toolbar" aria-label="Board actions">
      <div class="toolbar-row">
        <button type="button" class="chip ${J(`roster`)}" data-go="setup-roster">Setup roster</button>
        <button type="button" class="chip ${J(`committee`)}" data-go="setup-committee">Setup committee</button>
        <button type="button" class="chip ${J(`firstBoard`)}" data-go="setup-first-board">Setup first board</button>
        <button type="button" class="chip ${J(`factors25`)}" data-go="setup-25-factor">Setup 25-factor</button>
      </div>
      <div class="toolbar-row">
        <button type="button" class="chip primary" data-go="update-week">Update this week</button>
        <button type="button" class="chip accent" data-action="next-week">Start Week ${e.weekNumber+1}</button>
        <button type="button" class="chip" data-action="export-csv">Download CSV</button>
        <a class="chip" href="./download-windows.html">Windows zip</a>
      </div>
    </section>
  `}function Ce(){return Z()}function X(e,t,n){let r=e===`committee`?`committee`:e===`firstBoard`?`firstBoard`:`factors25`;return`
    <section class="panel">
      <div class="panel-head">
        <div>
          <h2>${t}</h2>
          <p>${n}</p>
        </div>
        <div class="inline-actions">
          <button type="button" class="btn ghost" data-go="combined">Back to sheet</button>
          <button type="button" class="btn primary" data-action="mark-setup" data-setup="${e}">Mark setup done</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Team</th>
              <th class="num">Record</th>
              <th class="num">Rank</th>
            </tr>
          </thead>
          <tbody>
            ${[...G().teams].sort((e,t)=>(e[r]||999)-(t[r]||999)||e.team.localeCompare(t.team)).map(e=>`
              <tr>
                <td class="team">${E(e.team)}</td>
                <td class="num">${e.wins}-${e.losses}</td>
                <td class="num">
                  <input class="rank-input" type="number" min="0" max="99" inputmode="numeric" data-team="${E(e.id)}" data-field="${r}" value="${e[r]||``}" />
                </td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </section>
  `}function we(){let e=G();return`
    <section class="panel">
      <div class="panel-head">
        <div>
          <h2>Setup roster</h2>
          <p>Add teams for ${B.activeYear}. Records start here and carry week to week.</p>
        </div>
        <div class="inline-actions">
          <button type="button" class="btn ghost" data-go="combined">Back to sheet</button>
          <button type="button" class="btn primary" data-action="mark-setup" data-setup="roster">Mark setup done</button>
        </div>
      </div>
      <form class="add-row" data-action="add-team">
        <input name="team" type="text" placeholder="Team name" required />
        <input name="wins" type="number" min="0" value="0" aria-label="Wins" />
        <input name="losses" type="number" min="0" value="0" aria-label="Losses" />
        <button type="submit" class="btn primary">Add team</button>
      </form>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Team</th>
              <th class="num">Wins</th>
              <th class="num">Losses</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${e.teams.map(e=>`
              <tr>
                <td class="team">${E(e.team)}</td>
                <td class="num"><input class="rank-input" type="number" min="0" max="30" inputmode="numeric" data-team="${E(e.id)}" data-field="wins" value="${e.wins}" /></td>
                <td class="num"><input class="rank-input" type="number" min="0" max="30" inputmode="numeric" data-team="${E(e.id)}" data-field="losses" value="${e.losses}" /></td>
                <td class="num"><button type="button" class="btn tiny danger" data-action="remove-team" data-team="${E(e.id)}">Remove</button></td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </section>
  `}function Te(){let e=G(),t=l(e.teams);return`
    <section class="panel">
      <div class="panel-head">
        <div>
          <h2>Update ${e.label}</h2>
          <p>Log each result. Wins and losses are added to the board automatically.</p>
        </div>
        <div class="inline-actions">
          <button type="button" class="btn ghost" data-go="combined">Back to sheet</button>
          <button type="button" class="btn accent" data-action="next-week">Start next week</button>
        </div>
      </div>

      <form class="result-form" data-action="log-result">
        <label>
          <span>Winner</span>
          <select name="winner" required>
            <option value="">Select winner</option>
            ${e.teams.map(e=>`<option value="${E(e.id)}">${E(e.team)}</option>`).join(``)}
          </select>
        </label>
        <label>
          <span>Loser</span>
          <select name="loser" required>
            <option value="">Select loser</option>
            ${e.teams.map(e=>`<option value="${E(e.id)}">${E(e.team)}</option>`).join(``)}
          </select>
        </label>
        <label>
          <span>Note</span>
          <input name="note" type="text" placeholder="Optional score or note" />
        </label>
        <button type="submit" class="btn primary">Add win / loss</button>
      </form>

      <div class="meta-row">
        <label>
          <span>Games through</span>
          <input type="text" data-week-field="gamesThrough" value="${Q(e.gamesThrough)}" placeholder="e.g. Nov. 22, 2026" />
        </label>
        <label>
          <span>Week notes</span>
          <input type="text" data-week-field="notes" value="${Q(e.notes)}" placeholder="What changed this week" />
        </label>
      </div>

      ${e.results.length?`<div class="results-list">
              <h3>Logged this week</h3>
              <ul>
                ${e.results.map(t=>`
                  <li>
                    <span><strong>${E(m(e,t.winnerId))}</strong> beat <strong>${E(m(e,t.loserId))}</strong>${t.note?` · ${E(t.note)}`:``}</span>
                    <button type="button" class="btn tiny ghost" data-action="undo-result" data-result="${E(t.id)}">Undo</button>
                  </li>`).join(``)}
              </ul>
            </div>`:`<p class="empty">No results logged yet for this week.</p>`}
    </section>

    <section class="panel">
      <div class="panel-head">
        <h2>Records and source ranks</h2>
        <p>Edit wins, losses, and the three setups for the active week.</p>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Team</th>
              <th class="num">W</th>
              <th class="num">L</th>
              <th class="num">Committee</th>
              <th class="num">First board</th>
              <th class="num">25 factors</th>
              <th class="num">Combined</th>
            </tr>
          </thead>
          <tbody>
            ${t.map(e=>`
              <tr>
                <td class="team">${E(e.team)}</td>
                <td class="num"><input class="rank-input" type="number" min="0" max="30" inputmode="numeric" data-team="${E(e.id)}" data-field="wins" value="${e.wins}" /></td>
                <td class="num"><input class="rank-input" type="number" min="0" max="30" inputmode="numeric" data-team="${E(e.id)}" data-field="losses" value="${e.losses}" /></td>
                <td class="num"><input class="rank-input" type="number" min="0" max="99" inputmode="numeric" data-team="${E(e.id)}" data-field="committee" value="${e.committee||``}" /></td>
                <td class="num"><input class="rank-input" type="number" min="0" max="99" inputmode="numeric" data-team="${E(e.id)}" data-field="firstBoard" value="${e.firstBoard||``}" /></td>
                <td class="num"><input class="rank-input" type="number" min="0" max="99" inputmode="numeric" data-team="${E(e.id)}" data-field="factors25" value="${e.factors25||``}" /></td>
                <td class="num"><span class="rank">${e.combined}</span></td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </section>
  `}function Z(){let e=G(),t=l(e.teams),n=t.slice(0,3),r=e.notes||`Each team’s combined place is the average of three ranks. Ties go to the committee order.`;return`
    ${Se(e)}

    <section class="topline sheet-topline" aria-label="Top of the board">
      ${n.length?n.map((e,t)=>`
            <div class="stat">
              <strong>${E(e.team)}</strong>
              <span>${t===0?`1st on the combined board`:t===1?`2nd, average rank ${e.averageLabel}`:`3rd, average rank ${e.averageLabel}`}</span>
            </div>`).join(``):`<div class="stat"><strong>No teams yet</strong><span>Use Setup roster to begin.</span></div>`}
    </section>

    <section class="panel">
      <div class="panel-head">
        <div>
          <h2>Combined 1–25</h2>
          <p>Average of committee + first board + 25-factor board</p>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th class="num">Combined</th>
              <th>Team</th>
              <th class="num">Record</th>
              <th class="num">Average</th>
              <th class="num">Committee</th>
              <th class="num">First board</th>
              <th class="num">25 factors</th>
            </tr>
          </thead>
          <tbody>
            ${t.map((e,t)=>`
              <tr style="animation-delay:${t*12}ms">
                <td class="num"><span class="rank">${e.combined}</span></td>
                <td class="team">${E(e.team)}</td>
                <td class="num">${e.record}</td>
                <td class="num">${e.averageLabel}</td>
                <td class="num">${e.committee||`—`}</td>
                <td class="num">${e.firstBoard||`—`}</td>
                <td class="num">${e.factors25||`—`}</td>
              </tr>`).join(``)}
          </tbody>
        </table>
      </div>
      <p class="note">${E(r)}</p>
      <p class="callout"><strong>How the three votes land.</strong> Each list counts once. A tie goes to the team the committee ranked higher.</p>
    </section>

    <section class="panel votes">
      <div class="panel-head">
        <h2>What was combined</h2>
        <p>Three finished rankings. Each one is one vote.</p>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th class="num">Vote</th>
              <th>Ranking</th>
              <th>What it already contains</th>
            </tr>
          </thead>
          <tbody>
            <tr><td class="num">1</td><td class="team">Committee</td><td>Results, schedule, head-to-head, common opponents, missing players, film, SportSource portal, conference input.</td></tr>
            <tr><td class="num">2</td><td class="team">First board</td><td>SP+, Sagarin, schedule, top-10/top-30 results, offense/defense/special teams, head-to-head.</td></tr>
            <tr><td class="num">3</td><td class="team">25-factor board</td><td>First board categories plus FPI, FEI, polls, résumé, margins, form, road, availability.</td></tr>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel inputs">
      <div class="panel-head">
        <h2>Every input, one through 26</h2>
        <p>Distinct pieces inside the three votes</p>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th class="num">#</th>
              <th>Input</th>
              <th>Where it is counted</th>
            </tr>
          </thead>
          <tbody>
            ${ae.map(e=>`<tr><td class="num">${e.num}</td><td class="team">${E(e.input)}</td><td>${E(e.where)}</td></tr>`).join(``)}
          </tbody>
        </table>
      </div>
    </section>
  `}function Q(e){return E(e)}function $(){let e=document.activeElement,t=q(e),n=e instanceof HTMLInputElement?e.selectionStart:null,r=G(),i=ve(),a=B.view===`setup-roster`?we():B.view===`setup-committee`?X(`committee`,`Setup committee`,`Enter the official CFP committee ranking for this week.`):B.view===`setup-first-board`?X(`firstBoard`,`Setup first board`,`Enter your first data-board ranking for this week.`):B.view===`setup-25-factor`?X(`factors25`,`Setup 25-factor board`,`Enter the 25-factor board ranking for this week.`):B.view===`update-week`?Te():B.view===`combined`?Z():Ce(),o=r.label.toLowerCase().includes(`week`)?`${r.label} re-rank`:`Week ${r.weekNumber} CFP re-rank`;z.innerHTML=`
    <div class="safety-strip ${U.ok?`ok`:`blocked`}" role="status">
      <strong>${E(U.name)}</strong>
      <span>${E(U.detail)}</span>
    </div>
    <header class="hero">
      <div class="hero-top">
        <img class="brand-mark" src="./cfp-logo.png" width="56" height="56" alt="CFP Re-Rank logo" />
        <div>
          <p class="kicker">College Football Playoff</p>
          <h1>${E(o)}</h1>
        </div>
      </div>
      <div class="hero-copy">
        <p class="lede">
          Games${r.gamesThrough?` through ${E(r.gamesThrough)}`:` this week`}.
          Each team’s combined place is the average of three ranks: the committee ranking, the first board, and the 25-factor board.
          Each list counts once. A tie goes to the team the committee ranked higher.
        </p>
        <p class="iphone-tip">
          <strong>iPhone:</strong> Safari → Share → <strong>Add to Home Screen</strong> for a one-tap CFP logo icon.
          <strong>Windows:</strong> run <em>Put Logo on Desktop.bat</em> once, then click the desktop logo anytime.
        </p>
      </div>
      <div class="control-bar">
        <label class="control">
          <span>Year</span>
          <select data-action="set-year">
            ${xe().map(e=>`<option value="${e}" ${e===B.activeYear?`selected`:``}>${e}${e===2026?` · this year`:``}</option>`).join(``)}
          </select>
        </label>
        <label class="control">
          <span>Week</span>
          <select data-action="set-week">
            ${i.weeks.map(e=>`<option value="${E(e.id)}" ${e.id===r.id?`selected`:``}>${E(e.label)}</option>`).join(``)}
          </select>
        </label>
        <button type="button" class="btn" data-action="new-year">Add next year</button>
        <button type="button" class="btn ghost" data-action="reset-year">Reset year seed</button>
        <a class="btn primary download-btn" href="./download-windows.html">Windows zip</a>
      </div>
    </header>
    ${a}
  `,be(t,n)}`serviceWorker`in navigator&&window.addEventListener(`load`,()=>{navigator.serviceWorker.register(`./sw.js`).catch(()=>{})}),z.addEventListener(`click`,e=>{let t=e.target.closest(`[data-go], [data-action]`);if(!t)return;let n=t.dataset.go;if(n){if(!U.ok)return;Y(n);return}let r=t.dataset.action;if(r&&(U.ok||r===`export-csv`)){if(r===`next-week`){let e=G(),t=u(e,e.weekNumber+1,B.activeYear);W(L(B,t),{immediate:!0})}else if(r===`export-csv`){let e=l(G().teams);p(`${G().label.toLowerCase().replace(/[^a-z0-9]+/g,`-`)}-combined-ranking.csv`,ne(e))}else if(r===`mark-setup`){let e=t.dataset.setup;e&&(ye(e,!0),Y(`combined`))}else if(r===`remove-team`){let e=t.dataset.team;if(!e)return;let n=G();W(I(B,{...n,teams:n.teams.filter(t=>t.id!==e),updatedAt:new Date().toISOString()}),{immediate:!0})}else if(r===`undo-result`){let e=t.dataset.result;if(!e)return;W(I(B,te(G(),e)),{immediate:!0})}else if(r===`new-year`){let e=Math.max(...B.seasons.map(e=>e.year))+1;W(F(B,e),{immediate:!0})}else r===`reset-year`&&confirm(`Reset ${B.activeYear} back to the starter board?`)&&W(ge(B),{immediate:!0})}}),z.addEventListener(`change`,e=>{if(!U.ok)return;let t=e.target;if(t.matches(`[data-action='set-year']`)){let e=S(t.value,2e3,2100);W(F(B,e),{immediate:!0})}else if(t.matches(`[data-action='set-week']`))W(R(B,w(t.value)),{immediate:!0});else if(t.matches(`[data-week-field]`)){let e=t.dataset.weekField,n=G();W(I(B,{...n,[e]:C(t.value,e===`notes`?240:64),updatedAt:new Date().toISOString()}))}else if(t.matches(`[data-team][data-field]`)){let e=t,n=w(e.dataset.team),r=e.dataset.field;if(r===`team`){K(n,{team:C(e.value)});return}let i=r===`wins`||r===`losses`?30:99;K(n,{[r]:S(e.value,0,i)})}}),z.addEventListener(`submit`,e=>{let t=e.target;if(t instanceof HTMLFormElement&&(e.preventDefault(),U.ok)){if(t.dataset.action===`add-team`){let e=new FormData(t),n=C(e.get(`team`));if(!n)return;let r=S(e.get(`wins`),0,30),i=S(e.get(`losses`),0,30),a=w(n),o=G();if(o.teams.length>=64)return;let s=o.teams.some(e=>e.id===a)?`${a}-${Date.now()}`:a;W(I(B,{...o,teams:[...o.teams,{id:s,team:n,wins:r,losses:i,committee:0,firstBoard:0,factors25:0}],setupDone:{...o.setupDone,roster:!0},updatedAt:new Date().toISOString()}),{immediate:!0})}else if(t.dataset.action===`log-result`){let e=new FormData(t),n=w(e.get(`winner`)),r=w(e.get(`loser`)),i=C(e.get(`note`),160);W(I(B,d(G(),n,r,i)),{immediate:!0})}}}),U.ok||z.classList.add(`desk-locked`),$();