param(
  [switch]$Quiet,
  [string]$SourceRoot = ""
)

$ErrorActionPreference = "Stop"
$ZipUrl = "https://raw.githubusercontent.com/bigred747/software/main/downloads/CFP-Re-Rank-Board-Windows11.zip"
$Permanent = Join-Path $env:USERPROFILE "Documents\CFP Re-Rank Board"
$Name = "CFP Re-Rank Board"

function Write-Step([string]$Message) {
  Write-Host $Message
}

function Test-TempZipPath([string]$PathValue) {
  if ([string]::IsNullOrWhiteSpace($PathValue)) { return $false }
  $text = ($PathValue -replace "/", "\").ToLowerInvariant()
  if ($text -like "*.zip.*") { return $true }
  if ($text -like "*\temp\*") { return $true }
  if ($text -like "*\temproary internet files\*") { return $true }
  return $false
}

function Test-Package([string]$Root) {
  if ([string]::IsNullOrWhiteSpace($Root)) { return $false }
  if (-not (Test-Path $Root)) { return $false }
  foreach ($item in @("Start CFP Re-Rank.bat", "start-server.ps1", "cfp-logo.ico", "app")) {
    if (-not (Test-Path (Join-Path $Root $item))) { return $false }
  }
  return $true
}

function Get-DesktopFolders {
  $candidates = New-Object System.Collections.Generic.List[string]
  function Add-Desktop([string]$PathValue) {
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return }
    if (-not (Test-Path $PathValue)) { return }
    $full = [System.IO.Path]::GetFullPath($PathValue)
    if (-not $candidates.Contains($full)) { $candidates.Add($full) }
  }
  Add-Desktop ([Environment]::GetFolderPath("Desktop"))
  Add-Desktop (Join-Path $env:USERPROFILE "Desktop")
  Add-Desktop (Join-Path $env:USERPROFILE "OneDrive\Desktop")
  Add-Desktop (Join-Path $env:USERPROFILE "OneDrive - Personal\Desktop")
  if ($env:OneDrive) { Add-Desktop (Join-Path $env:OneDrive "Desktop") }
  if ($env:OneDriveConsumer) { Add-Desktop (Join-Path $env:OneDriveConsumer "Desktop") }
  if ($env:OneDriveCommercial) { Add-Desktop (Join-Path $env:OneDriveCommercial "Desktop") }
  Add-Desktop ([Environment]::GetFolderPath("CommonDesktopDirectory"))
  return $candidates
}

function Install-FromRoot([string]$Root) {
  New-Item -ItemType Directory -Force -Path $Permanent | Out-Null
  Write-Step "Installing into: $Permanent"
  $robocopy = Join-Path $env:SystemRoot "System32\robocopy.exe"
  if (Test-Path $robocopy) {
    & $robocopy $Root $Permanent /E /XO /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
    if ($LASTEXITCODE -ge 8) {
      throw "Could not copy files into Documents\CFP Re-Rank Board (robocopy $LASTEXITCODE)."
    }
    foreach ($junk in @(
      (Join-Path $Permanent "app\CFP-Re-Rank-Board-Windows11.zip"),
      (Join-Path $Permanent "app\download-windows.html"),
      (Join-Path $Permanent "CFP-Re-Rank-Board-Windows11.zip")
    )) {
      if (Test-Path $junk) { Remove-Item -Force $junk }
    }
  } else {
    Copy-Item -Path (Join-Path $Root "*") -Destination $Permanent -Recurse -Force
  }
}

function Install-FromDownload {
  Write-Step "Package incomplete or opened inside the zip."
  Write-Step "Downloading the latest board from GitHub..."
  New-Item -ItemType Directory -Force -Path $Permanent | Out-Null
  $zipPath = Join-Path $env:TEMP "CFP-Re-Rank-Board-Windows11-latest.zip"
  $extract = Join-Path $env:TEMP ("CFP-Re-Rank-Extract-" + [guid]::NewGuid().ToString("N"))
  try {
    Invoke-WebRequest -Uri $ZipUrl -OutFile $zipPath -UseBasicParsing
    if (Test-Path $extract) { Remove-Item -Recurse -Force $extract }
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extract -Force
    $found = Get-ChildItem -Path $extract -Directory | Where-Object {
      Test-Package $_.FullName
    } | Select-Object -First 1
    if (-not $found) {
      $found = Get-ChildItem -Path $extract -Recurse -Directory | Where-Object {
        Test-Package $_.FullName
      } | Select-Object -First 1
    }
    if (-not $found) { throw "Downloaded zip did not contain the CFP package." }
    Install-FromRoot $found.FullName
  } finally {
    if (Test-Path $extract) { Remove-Item -Recurse -Force $extract -ErrorAction SilentlyContinue }
    if (Test-Path $zipPath) { Remove-Item -Force $zipPath -ErrorAction SilentlyContinue }
  }
}

function Create-DesktopShortcuts {
  $startBat = Join-Path $Permanent "Start CFP Re-Rank.bat"
  $icon = Join-Path $Permanent "cfp-logo.ico"
  $png = Join-Path $Permanent "cfp-logo.png"
  if (-not (Test-Path $startBat)) { throw "Install failed: missing Start CFP Re-Rank.bat in Documents." }
  if (-not (Test-Path $icon)) { throw "Install failed: missing cfp-logo.ico in Documents." }

  $desktops = Get-DesktopFolders
  if ($desktops.Count -eq 0) { throw "No Desktop folder found on this PC." }

  foreach ($desktop in $desktops) {
    foreach ($old in @("CFP Re-Rank.lnk", "CFP Re-Rank Board.lnk")) {
      $oldPath = Join-Path $desktop $old
      if (Test-Path $oldPath) { Remove-Item -Force $oldPath -ErrorAction SilentlyContinue }
    }
  }

  $shell = New-Object -ComObject WScript.Shell
  $created = @()
  foreach ($desktop in $desktops) {
    $shortcutPath = Join-Path $desktop ($Name + ".lnk")
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $startBat
    $shortcut.WorkingDirectory = $Permanent
    $shortcut.IconLocation = "$icon,0"
    $shortcut.WindowStyle = 1
    $shortcut.Description = "Open CFP Re-Rank Board"
    $shortcut.Save()
    $created += $shortcutPath
    Write-Step "Desktop icon: $shortcutPath"
    if (Test-Path $png) {
      Copy-Item -Force $png (Join-Path $desktop "CFP-Re-Rank-Logo.png")
    }
  }

  try {
    $reg = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    Set-ItemProperty -Path $reg -Name HideIcons -Value 0 -Type DWord -ErrorAction SilentlyContinue
  } catch {}

  return $created[0]
}

# Resolve local source if provided / adjacent
if (-not $SourceRoot) { $SourceRoot = $PSScriptRoot }
if (-not (Test-Package $SourceRoot)) {
  $parent = Split-Path -Parent $SourceRoot
  if (Test-Package $parent) { $SourceRoot = $parent }
}

$useLocal = (Test-Package $SourceRoot) -and -not (Test-TempZipPath $SourceRoot)
if ($useLocal) {
  Install-FromRoot $SourceRoot
} else {
  Install-FromDownload
}

$primary = Create-DesktopShortcuts
Write-Step "Done. Desktop name: $Name"
Write-Step "Installed to: $Permanent"

if (-not $Quiet) {
  Start-Process explorer.exe -ArgumentList @("/select,$primary")
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show(
    "Ready.`r`n`r`nDesktop name: $Name`r`n`r`nInstalled to:`r`n$Permanent`r`n`r`nShortcut:`r`n$primary`r`n`r`nFile Explorer opened with the icon selected. Double-click that.",
    $Name
  ) | Out-Null
}
