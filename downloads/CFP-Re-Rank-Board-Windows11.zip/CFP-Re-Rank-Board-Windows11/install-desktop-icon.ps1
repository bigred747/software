param(
  [switch]$Quiet
)

$ErrorActionPreference = "Stop"

function Write-Step([string]$Message) {
  Write-Host $Message
}

# Find the folder that contains Start CFP Re-Rank.bat (the zip root).
$sourceRoot = $PSScriptRoot
if (-not (Test-Path (Join-Path $sourceRoot "Start CFP Re-Rank.bat"))) {
  $parent = Split-Path -Parent $PSScriptRoot
  if (Test-Path (Join-Path $parent "Start CFP Re-Rank.bat")) {
    $sourceRoot = $parent
  }
}

$required = @(
  "Start CFP Re-Rank.bat",
  "start-server.ps1",
  "cfp-logo.ico",
  "app"
)

foreach ($item in $required) {
  $path = Join-Path $sourceRoot $item
  if (-not (Test-Path $path)) {
    throw "Missing '$item' next to the installer. Extract the whole zip first, then run Put Logo on Desktop.bat from inside that folder."
  }
}

# Permanent home so Desktop shortcut never points at a temp unzip fold.
$permanent = Join-Path $env:USERPROFILE "Documents\CFP Re-Rank Board"
New-Item -ItemType Directory -Force -Path $permanent | Out-Null

Write-Step "Installing board to: $permanent"
$robocopy = Join-Path $env:SystemRoot "System32\robocopy.exe"
if (Test-Path $robocopy) {
  & $robocopy $sourceRoot $permanent /E /XO /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
  if ($LASTEXITCODE -ge 8) {
    throw "Could not copy files into Documents\CFP Re-Rank Board (robocopy $LASTEXITCODE)."
  }
} else {
  Copy-Item -Path (Join-Path $sourceRoot "*") -Destination $permanent -Recurse -Force
}

$startBat = Join-Path $permanent "Start CFP Re-Rank.bat"
$icon = Join-Path $permanent "cfp-logo.ico"
$png = Join-Path $permanent "cfp-logo.png"
$name = "CFP Re-Rank Board"

if (-not (Test-Path $startBat)) { throw "Install failed: Start CFP Re-Rank.bat was not created in Documents." }
if (-not (Test-Path $icon)) { throw "Install failed: cfp-logo.ico was not created in Documents." }

$candidates = New-Object System.Collections.Generic.List[string]
function Add-Desktop([string]$PathValue) {
  if ([string]::IsNullOrWhiteSpace($PathValue)) { return }
  if (-not (Test-Path $PathValue)) { return }
  $full = [System.IO.Path]::GetFullPath($PathValue)
  if (-not $candidates.Contains($full)) { $candidates.Add($full) }
}

Add-Desktop ([Environment]::GetFolderPath("Desktop"))
Add-Desktop (Join-Path $env:USERPROFILE "Desktop")
Add-Desktop (Join-Path $env:USERPROFILE "OneDrive\Desktop")
Add-Desktop (Join-Path $env:USERPROFILE "OneDrive - Personal\Desktop")
if ($env:OneDrive) { Add-Desktop (Join-Path $env:OneDrive "Desktop") }
if ($env:OneDriveConsumer) { Add-Desktop (Join-Path $env:OneDriveConsumer "Desktop") }
if ($env:OneDriveCommercial) { Add-Desktop (Join-Path $env:OneDriveCommercial "Desktop") }
Add-Desktop ([Environment]::GetFolderPath("CommonDesktopDirectory"))

if ($candidates.Count -eq 0) {
  throw "No Desktop folder found on this PC."
}

# Remove old broken shortcut names from earlier builds.
$oldNames = @("CFP Re-Rank.lnk", "CFP Re-Rank Board.lnk")
foreach ($desktop in $candidates) {
  foreach ($old in $oldNames) {
    $oldPath = Join-Path $desktop $old
    if (Test-Path $oldPath) { Remove-Item -Force $oldPath -ErrorAction SilentlyContinue }
  }
}

$shell = New-Object -ComObject WScript.Shell
$created = @()
foreach ($desktop in $candidates) {
  $shortcutPath = Join-Path $desktop ($name + ".lnk")
  $shortcut = $shell.CreateShortcut($shortcutPath)
  $shortcut.TargetPath = $startBat
  $shortcut.WorkingDirectory = $permanent
  $shortcut.IconLocation = "$icon,0"
  $shortcut.WindowStyle = 1
  $shortcut.Description = "Open CFP Re-Rank Board"
  $shortcut.Save()
  $created += $shortcutPath
  Write-Step "Desktop icon: $shortcutPath"
  if (Test-Path $png) {
    Copy-Item -Force $png (Join-Path $desktop "CFP-Re-Rank-Logo.png")
  }
}

try {
  $reg = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
  Set-ItemProperty -Path $reg -Name HideIcons -Value 0 -Type DWord -ErrorAction SilentlyContinue
} catch {}

$primary = $created[0]
if (-not $Quiet) {
  Start-Process explorer.exe -ArgumentList @("/select,$primary")
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show(
    "Ready.`r`n`r`nDesktop name: $name`r`n`r`nInstalled to:`r`n$permanent`r`n`r`nShortcut:`r`n$primary`r`n`r`nFile Explorer opened with the icon selected. Double-click that.",
    "CFP Re-Rank Board"
  ) | Out-Null
}
