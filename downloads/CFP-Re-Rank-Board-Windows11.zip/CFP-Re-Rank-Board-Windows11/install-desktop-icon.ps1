$ErrorActionPreference = "Stop"
$desk = $PSScriptRoot
$startBat = Join-Path $desk "Start CFP Re-Rank.bat"
$icon = Join-Path $desk "cfp-logo.ico"
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "CFP Re-Rank.lnk"
if (-not (Test-Path $startBat)) { throw "Missing Start CFP Re-Rank.bat" }
if (-not (Test-Path $icon)) { throw "Missing cfp-logo.ico" }
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $startBat
$shortcut.WorkingDirectory = $desk
$shortcut.IconLocation = "$icon,0"
$shortcut.Description = "Open CFP Re-Rank Board"
$shortcut.Save()
Write-Host "Created $shortcutPath"
