@echo off
setlocal EnableExtensions
title CFP Re-Rank Board

set "HOME=%USERPROFILE%\Documents\CFP Re-Rank Board"

REM Prefer the permanent install. If missing, run the logo installer first.
if not exist "%HOME%\start-server.ps1" (
  echo  First-time setup: installing board into Documents...
  if exist "%~dp0Put Logo on Desktop.bat" (
    call "%~dp0Put Logo on Desktop.bat"
  ) else if exist "%~dp0install-desktop-icon.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-desktop-icon.ps1" -Quiet
  ) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/bigred747/software/main/downloads/INSTALL-CFP-Re-Rank.bat' -OutFile (Join-Path $env:TEMP 'INSTALL-CFP-Re-Rank.bat') -UseBasicParsing; Start-Process -Wait -FilePath (Join-Path $env:TEMP 'INSTALL-CFP-Re-Rank.bat')"
  )
)

if not exist "%HOME%\start-server.ps1" (
  echo.
  echo  Board is not installed yet.
  echo  Right-click the zip - Extract All - then run Put Logo on Desktop.bat
  echo.
  pause
  exit /b 1
)

cd /d "%HOME%"
echo.
echo  CFP Re-Rank Board  ^|  Artex-safe local desk
echo  http://127.0.0.1:3847
echo  Leave this window open while you use the board.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%HOME%\start-server.ps1"
if errorlevel 1 (
  echo.
  echo  Could not start. Run Put Logo on Desktop.bat again.
  pause
)
