@echo off
setlocal
cd /d "%~dp0"
title CFP Re-Rank Board
if not exist "%USERPROFILE%\Desktop\CFP Re-Rank.lnk" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-desktop-icon.ps1" >nul 2>&1
)
echo.
echo  CFP Re-Rank Board  ^|  Artex-safe local desk
echo  http://127.0.0.1:3847
echo  Leave this window open while you use the board.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-server.ps1"
if errorlevel 1 (
  echo.
  echo  Could not start. Extract to Documents\CFP Re-Rank Board first.
  echo  Do not run from an Artex folder or a temporary zip fold.
  pause
)
