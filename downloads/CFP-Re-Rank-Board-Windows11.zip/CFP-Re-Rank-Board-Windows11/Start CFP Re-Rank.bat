@echo off
setlocal EnableExtensions
title CFP Re-Rank Board

set "HOME=%USERPROFILE%\Documents\CFP Re-Rank Board"

if not exist "%HOME%\start-server.ps1" (
  echo  Board is not installed yet.
  echo  Right-click the zip - Extract All - then run Put Logo on Desktop.bat
  echo.
  pause
  exit /b 1
)

cd /d "%HOME%"
echo.
echo  CFP Re-Rank Board
echo  http://127.0.0.1:3847
echo  Leave this window open while you use the board.
echo.
powershell -NoProfile -File "%HOME%\start-server.ps1"
if errorlevel 1 (
  echo.
  echo  Could not start.
  echo  If Bitdefender blocked PowerShell, allow this folder:
  echo  %HOME%
  echo.
  pause
)
