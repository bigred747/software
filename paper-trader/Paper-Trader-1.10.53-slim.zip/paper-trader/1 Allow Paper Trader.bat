@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo %~dp0 | findstr /I /C:"\Temp" | findstr /I /C:".zip." >nul
if not errorlevel 1 goto FromZip
goto Normal

:FromZip
echo Unblock
echo If Windows shows an Unblock box, check Unblock and open this file.
echo That box lets this copy open. It stays on this computer.
echo This file was opened inside the zip. Extracting the whole Paper Trader now.
set "ZIP="
set "PYTRY=python"
if exist "%~dp0runtime\python.exe" set "PYTRY=%~dp0runtime\python.exe"
for /f "delims=" %%Z in ('"%PYTRY%" "%~dp0tools\pick_upgrade_zip.py" 2^>nul') do set "ZIP=%%Z"
if not defined ZIP if exist "%USERPROFILE%\Downloads\Paper-Trader.zip" set "ZIP=%USERPROFILE%\Downloads\Paper-Trader.zip"
if not defined ZIP goto NoZip
if /I "!ZIP!"=="NONE" goto NoZip
echo Using zip: !ZIP!
echo Close every Paper Trader window and black cmd desk window first.
if not exist "%USERPROFILE%\Documents" mkdir "%USERPROFILE%\Documents"
rem Never reuse Documents\PaperTrader-setup — a running desk locks learn.lock there.
set "STAGE=%USERPROFILE%\Documents\PaperTrader-setup-%RANDOM%%RANDOM%"
mkdir "%STAGE%" 2>nul
if not exist "%STAGE%\." set "STAGE=%USERPROFILE%\Documents\PaperTrader-setup-%RANDOM%%RANDOM%"
mkdir "%STAGE%" 2>nul
if not exist "%STAGE%\." goto BadZip
echo Extracting into: !STAGE!
tar -xf "!ZIP!" -C "!STAGE!"
if errorlevel 1 goto BadZip
if not exist "!STAGE!\paper-trader\Start-Paper-Trader.bat" goto BadZip
start "" "!STAGE!\paper-trader\Start-Paper-Trader.bat"
echo The full copy is in Documents. Use the window that just opened.
pause
exit /b 0

:NoZip
echo Could not find Paper-Trader.zip in Downloads, Desktop, Documents, or OneDrive.
echo Save the FULL Paper-Trader.zip in Downloads, then double-click this file again.
pause
exit /b 1

:BadZip
echo Could not extract Paper-Trader.zip.
echo Close EVERY Paper Trader window and black cmd window, then try again.
echo Or right-click the zip - Extract All - then open Start-Paper-Trader.bat.
pause
exit /b 1

:Normal
echo Unblock
echo If Windows shows an Unblock box, check Unblock and open this file.
echo.
echo Prefer the FULL Paper-Trader.zip so runtime\python.exe is included.
echo If Documents is stuck on an old seal, use FORCE-UPGRADE.bat from a fresh Extract All.
echo.
set "PY=%~dp0runtime\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" "%~dp0launch.py" install > "%USERPROFILE%\Documents\paper-trader-install.txt" 2>&1
if errorlevel 1 (
  echo Could not install. See Documents\paper-trader-install.txt
  type "%USERPROFILE%\Documents\paper-trader-install.txt"
  echo.
  echo If stuck, close every desk window and run FORCE-UPGRADE.bat from this extract.
  pause
  exit /b 1
)
set "DEST=%USERPROFILE%\Documents\Paper Trader"
set "WANT="
if exist "%~dp0VERSION" set /p WANT=<"%~dp0VERSION"
set "SEAL="
if exist "!DEST!\VERSION" set /p SEAL=<"!DEST!\VERSION"
echo Documents\Paper Trader seal: !SEAL!  ^(pack !WANT!^)
if exist "!DEST!\Start-Paper-Trader.bat" (
  start "Paper Trader" /D "!DEST!" cmd /c "2 Open Paper Trader.bat"
) else (
  echo Documents\Paper Trader missing. Run FORCE-UPGRADE.bat from this extract.
)
pause
exit /b 0
