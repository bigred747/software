<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared options. Safe public-output repairs default on.
 */
class Luxe_Score_Repair_Plugin {

	const OPTION = 'luxe_score_repair_settings';

	/**
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return array<string,int>
	 */
	public static function defaults() {
		return array(
			'fix_titles'            => 1,
			'fix_robots_txt'        => 1,
			'noindex_utility'       => 1,
			'fix_schema'            => 1,
			'fix_open_graph'        => 1,
			'clean_content'         => 1,
			'clean_titles'          => 1,
			'fix_headers'           => 1,
			'repair_known_404s'     => 1,
			'buffer_html'           => 1,
			'image_alts'            => 1,
			'hide_generator'        => 1,
			'affiliate_disclosure'  => 1,
			'process_learning'      => 1,
			'auto_purge'            => 1,
			'copyright_lock'        => 1,
			'unique_copy'           => 1,
			'amazon_ai'             => 1,
			'amazon_tag'            => 'luxetrendse0f-20',
			'amazon_client_id'      => '',
			'amazon_client_secret'  => '',
			'amazon_marketplace'    => 'www.amazon.com',
		);
	}

	/**
	 * Store defaults. Do not write content.
	 */
	public static function activate() {
		$settings = get_option( self::OPTION );
		if ( ! is_array( $settings ) ) {
			add_option( self::OPTION, self::defaults(), '', false );
		} else {
			update_option( self::OPTION, wp_parse_args( $settings, self::defaults() ), false );
		}
		add_option( 'luxe_score_repair_activated_at', time(), '', false );
		Luxe_Score_Repair_Learning::activate();
		Luxe_Score_Repair_Amazon::activate();
	}

	/**
	 * Deactivation leaves options so a re-activate keeps choices.
	 */
	public static function deactivate() {
		Luxe_Score_Repair_Learning::deactivate();
		Luxe_Score_Repair_Amazon::deactivate();
		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}
	}

	/**
	 * Register runtime modules.
	 */
	public function boot() {
		add_action( 'admin_init', array( $this, 'maybe_save_settings' ) );

		Luxe_Score_Repair_SEO::instance()->boot();
		Luxe_Score_Repair_Schema::instance()->boot();
		Luxe_Score_Repair_Robots::instance()->boot();
		Luxe_Score_Repair_Content::instance()->boot();
		Luxe_Score_Repair_Headers::instance()->boot();
		Luxe_Score_Repair_Redirects::instance()->boot();
		Luxe_Score_Repair_Buffer::instance()->boot();
		Luxe_Score_Repair_Learning::instance()->boot();
		Luxe_Score_Repair_Amazon::instance()->boot();

		if ( is_admin() ) {
			Luxe_Score_Repair_Admin::instance()->boot();
		}
	}

	/**
	 * @return array<string,int>
	 */
	public function settings() {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		return wp_parse_args( $stored, self::defaults() );
	}

	/**
	 * @param string $key Setting key.
	 * @return bool
	 */
	public function enabled( $key ) {
		$settings = $this->settings();
		return ! empty( $settings[ $key ] );
	}

	/**
	 * Persist admin checkboxes.
	 */
	public function maybe_save_settings() {
		if ( empty( $_POST['luxe_score_repair_save'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'luxe_score_repair_save' );

		$prev = $this->settings();
		$next = array();
		foreach ( self::defaults() as $key => $default ) {
			if ( is_int( $default ) ) {
				$next[ $key ] = empty( $_POST[ $key ] ) ? 0 : 1;
			}
		}
		$tag = isset( $_POST['amazon_tag'] ) ? sanitize_text_field( wp_unslash( $_POST['amazon_tag'] ) ) : ( isset( $prev['amazon_tag'] ) ? $prev['amazon_tag'] : Luxe_Score_Repair_Amazon::TAG );
		$next['amazon_tag']         = Luxe_Score_Repair_Amazon::sanitize_tag( $tag );
		$next['amazon_marketplace'] = Luxe_Score_Repair_Amazon::MARKET;
		$next['amazon_client_id']   = isset( $_POST['amazon_client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['amazon_client_id'] ) ) : ( isset( $prev['amazon_client_id'] ) ? $prev['amazon_client_id'] : '' );
		$secret = isset( $_POST['amazon_client_secret'] ) ? trim( (string) wp_unslash( $_POST['amazon_client_secret'] ) ) : '';
		$next['amazon_client_secret'] = ( '' !== $secret ) ? $secret : ( isset( $prev['amazon_client_secret'] ) ? $prev['amazon_client_secret'] : '' );
		update_option( self::OPTION, $next, false );
		if ( ! empty( $next['amazon_ai'] ) ) {
			Luxe_Score_Repair_Amazon::activate();
		} else {
			Luxe_Score_Repair_Amazon::deactivate();
		}
		Luxe_Score_Repair_Robots::heal_file();
		Luxe_Score_Repair_Learning::purge_caches();
		add_settings_error(
			'luxe_score_repair',
			'saved',
			__( 'SEO settings saved. Amazon AI, robots.txt, and caches updated. Open the green signal board below.', 'luxe-score-repair' ),
			'updated'
		);
	}

	/**
	 * Brand homepage title. 50–60 characters.
	 *
	 * @return string
	 */
	public static function home_title() {
		return 'LuxeTrendsetters | Luxury Tech, Watches & Drones';
	}

	/**
	 * Brand homepage meta description. 140–160 characters.
	 *
	 * @return string
	 */
	public static function home_description() {
		return 'Curated luxury tech, watches, drones, audio, and smart gear. Compare premium Amazon picks with clear buyer guides from LuxeTrendsetters.';
	}

	/**
	 * @return string
	 */
	public static function brand_name() {
		$name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		return $name ? $name : 'LuxeTrendsetters';
	}

	/**
	 * Best available brand image (site icon, then custom logo).
	 *
	 * @return string
	 */
	public static function brand_image() {
		$icon = get_site_icon_url( 512 );
		if ( is_string( $icon ) && $icon ) {
			return $icon;
		}
		$logo_id = (int) get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$url = wp_get_attachment_image_url( $logo_id, 'full' );
			if ( is_string( $url ) && $url ) {
				return $url;
			}
		}
		return '';
	}

	/**
	 * Utility / junk paths that must not rank.
	 *
	 * @return string[]
	 */
	public static function noindex_slugs() {
		return array(
			'cart',
			'checkout',
			'my-account',
			'wishlist',
			'wish-list',
			'client-portal',
			'test-blog-page',
			'thank-you-appointment',
			'thank-you-for-contacting-us',
		);
	}

	/**
	 * Current request path without query string, leading slash, no trailing slash except root.
	 *
	 * @return string
	 */
	public static function request_path() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$path = wp_parse_url( $uri, PHP_URL_PATH );
		if ( ! is_string( $path ) || '' === $path ) {
			$path = '/';
		}
		$home_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( is_string( $home_path ) && '/' !== $home_path && 0 === strpos( $path, rtrim( $home_path, '/' ) ) ) {
			$path = substr( $path, strlen( rtrim( $home_path, '/' ) ) );
			if ( ! is_string( $path ) || '' === $path ) {
				$path = '/';
			}
		}
		if ( '' === $path || '/' !== $path[0] ) {
			$path = '/' . ltrim( $path, '/' );
		}
		if ( '/' === $path ) {
			return '/';
		}
		return untrailingslashit( $path );
	}

	/**
	 * Whether this request is a public HTML document we may rewrite.
	 *
	 * @return bool
	 */
	public static function is_public_html_request() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return false;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return false;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( preg_match( '#/(robots\.txt|sitemap[^/]*\.xml|wp-cron\.php|xmlrpc\.php|wp-json/)#i', $uri ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Yellow (unverified) rows are excluded so Hostinger loopback cannot fake-fail the score.
	 *
	 * @param int $green  Green count.
	 * @param int $total  Total signals.
	 * @param int $yellow Yellow count.
	 * @return float
	 */
	public static function score_10( $green, $total, $yellow = 0 ) {
		$counted = (int) $total - (int) $yellow;
		if ( $counted < 1 ) {
			return 0;
		}
		return round( 10 * ( (int) $green / $counted ), 1 );
	}

	/**
	 * @param array $signals Signals.
	 * @return string
	 */
	public static function seo_band( $signals ) {
		$map        = array();
		$has_red    = false;
		$has_yellow = false;
		if ( ! is_array( $signals ) ) {
			return 'repairing';
		}
		foreach ( $signals as $signal ) {
			if ( ! is_array( $signal ) || empty( $signal['id'] ) ) {
				continue;
			}
			$level = isset( $signal['level'] ) ? (string) $signal['level'] : 'red';
			$map[ $signal['id'] ] = $level;
			if ( 'red' === $level ) {
				$has_red = true;
			}
			if ( 'yellow' === $level ) {
				$has_yellow = true;
			}
		}
		$need = array( 'home_title', 'home_description', 'schema', 'robots_file', 'noindex_test', 'alts', 'copyright_lock', 'unique_copy' );
		foreach ( $need as $id ) {
			if ( isset( $map[ $id ] ) && 'red' === $map[ $id ] ) {
				return 'repairing';
			}
		}
		if ( $has_red ) {
			return 'repairing';
		}
		if ( $has_yellow ) {
			foreach ( $signals as $signal ) {
				if ( ! is_array( $signal ) ) {
					continue;
				}
				if ( 'yellow' !== ( isset( $signal['level'] ) ? $signal['level'] : '' ) ) {
					continue;
				}
				$id = isset( $signal['id'] ) ? $signal['id'] : '';
				if ( ! in_array( $id, array( 'headers', 'blog_301' ), true ) ) {
					return 'unverified-loopback';
				}
			}
		}
		if ( isset( $map['robots_public'] ) && 'green' !== $map['robots_public'] ) {
			return '95-pending-cdn';
		}
		return '95-100-ready';
	}

	/**
	 * @return string
	 */
	public static function unverified_detail() {
		return 'Unverified: live fetch skipped (loopback). Repair is on. This row is not a live HTML pass.';
	}

	/**
	 * Hostinger loopback often hides HSTS. Do not fake-fail a live HTTPS site.
	 *
	 * @param bool $hsts         HSTS header present.
	 * @param bool $public_cache Cache-Control public present.
	 * @param bool $html_ok      Homepage HTML fetched.
	 * @return string green|yellow|red
	 */
	public static function headers_probe_level( $hsts, $public_cache, $html_ok ) {
		if ( $hsts && $public_cache && $html_ok ) {
			return 'green';
		}
		if ( $html_ok ) {
			return 'yellow';
		}
		return 'yellow';
	}

	/**
	 * @param int    $code     HTTP code.
	 * @param string $location Location header.
	 * @param string $final    Final URL.
	 * @return bool
	 */
	public static function blog_hop_ok( $code, $location, $final ) {
		$location = (string) $location;
		$final    = (string) $final;
		if ( false !== strpos( $location, '/blogs' ) ) {
			return true;
		}
		if ( in_array( (int) $code, array( 301, 302 ), true ) && false !== strpos( $final, '/blogs' ) ) {
			return true;
		}
		if ( 200 === (int) $code && false !== strpos( $final, '/blogs' ) ) {
			return true;
		}
		return false;
	}
}
