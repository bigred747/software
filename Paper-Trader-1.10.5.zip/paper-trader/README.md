# Paper Trader

A local paper desk. The computer copy loads market quotes for 7,500 stocks, ETFs, futures, and crypto names, including Bitcoin, XRP, and Stellar. It shows the quote time, a candle chart, buy and sell arrows, squeeze compression, four indicator readings, and a simulated account.

Orders stay on the paper account. The desk listens only on this computer. It does not place broker orders, connect to an exchange account, or collect payments.

The quote is the market's latest price from the feed, not a generated series and not a forecast. The header shows when that price was quoted. US stocks and ETFs after the cash close show that session's closing price. Crypto and many futures keep updating outside the stock session. If the feed does not answer, the desk shows the error and does not invent a price.

## Run it

Right-click `Paper-Trader.zip`, choose Extract All, and put the folder in Documents. Then two clicks:

1. Double-click `1 Allow Paper Trader.bat`. That clears the download block, puts the newest copy in Documents, leaves any older Paper Trader folders where they are (the Safe check lists them so you can delete them yourself), and puts **Paper Trader** on the desktop.
2. Double-click **Paper Trader** on the desktop. The desk opens, **Auto** starts, and the **Signals** list turns green for each part that is working. Click **Auto** again to stop.

If a file is opened from inside the zip, version 1.9.38 looks for Paper-Trader.zip in Downloads, Desktop, Documents, and OneDrive, makes the folders in Documents first, then extracts the whole zip and opens a window named Paper Trader. It puts Paper Trader.bat on the desktop, including the OneDrive desktop. It also copies PaperTrader.html into Documents\iPhone and opens that folder. Older Paper Trader folders are never deleted for you. The chart leaves open space on the right of the last candle and shows the last price there. Click a candle to drop a vertical price line on that bar; the close is marked on the right. Voice speaks only for the daily squeeze: a buy or sell warning when five squeeze dots print, before the release, and sell when that momentum turns down. This copy does not run PowerShell, does not hide a window, and does not change Windows security settings. If Windows shows an Unblock box, check Unblock and open the file. That box lets this copy open. Leave that window open so the desk stays on the screen. Microsoft Edge opens when the desk answers. The header says Desk is working when the page has started. The green signals sit on the chart and show version 1.9.38 when this copy is running. The Daily scan section lists the strongest closed-bar scores from the full catalog, and today's three to five best names sit under that list. Scanner on walks the catalog. Scanner off pauses that walk. The chart quote and the Paper Trader Learn window keep going, and names already found stay listed. A new paper buy has to be one of those names, and the day stops at five new buys. On iPhone the same page scans live crypto into that section. Opening the GitHub link in the browser leaves the charts off. Download the file, open Files, tap Share, then Edge. SMH, VGT, ARKW, QQQ, SPMO, COPX, ARKQ, MGK, CIBR, UGA, AIRR, and GRID stay on the watch list with the other pinned markets. Learning, Fear and greed, and Zoom each have their own green dot. The header clock is a pie of that score, with an arrow pointing at the number. Candles are green or red. The chart shows the high, close, and low averages, momentum, squeeze dots, resistance and support, and a true-momentum study under the price. The score is its own process. Closing the Paper Trader window does not stop it. Starting that window at sign-in is optional: tick Start the score when I sign in to Windows under Windows extras in the Safe check, and untick it to remove the file. It is off until you tick it. The score keeps scoring while the computer is on and you are signed in. It does not run while the computer is off. While that window is open on wall power, it asks Windows not to sleep, so scoring keeps going all day and all week. The screen can still turn off, and the lock screen still works. On battery, Windows can still sleep. Closing the window ends that request. The desk does not hide that window and does not change Windows security settings. A feed error stays on the Learning signal. The setup window can close. When the older folder is still locked, the new copy opens from Documents\PaperTrader-setup anyway. Click a candle and that bar's prices appear on the chart. Zoom in and Zoom out change how many bars a chart shows.

From a source checkout, Python 3.11 or newer is enough. The desk uses the Python standard library, so startup does not install packages.

```bash
cd paper-trader
python -m paper_trader serve
```

Microsoft Edge opens to `http://127.0.0.1:8765/`.

- **Auto** starts with the desk and refreshes the market quote. Click it again to stop. Each fill stays simulated.
- **Trade** places one simulated order on the paper account at the latest quote. A new buy is allowed only after the scan finishes, for a name in the green list: the ten highest closed-bar scores narrowed to three to five. A sixth new buy is refused. One new buy per market per day. A sell is always allowed. That score is the past match rate. It is not a forecast. It does not send an order to a broker.
- **Daily scan** walks every market in the catalog once each Denver day, while this computer is on and you are signed in. The Daily scan section lists ten markets that cleared that same closed-bar bar, then narrows those ten to three to five. A green signal lights on each of those names when the scan finishes. It does not invent a price when a quote fails. The list is not a forecast. **Scanner on** walks the catalog. **Scanner off** pauses that walk. The chart quote and the Paper Trader Learn window keep going, and names already found stay listed.
- **Paper** turns the paper account on. The button stays pressed, and the desk refuses any other account.
- **Fills** work like a live market order. Trade and Sell all fill at the latest real trade from the quote feed at the moment you click, moved 5 basis points against you for slippage, plus the fee. That price is locked into the paper record, so it does not drift as the day's quote keeps moving. The status line and the ticket show the fill price, the last trade, the slippage, the fee, and the time in Denver time. The paper account has no margin and no shorting: a buy uses the paper cash, and a sell closes the whole position.
- **Live** is locked. This desk has no broker or bank link, so it cannot connect to an institution and every order stays paper. Clicking Live says so and changes nothing. To trade real money, use your broker's own app.
- **Sell all · Stop buys** is the circuit breaker. One click sells the open paper position at the latest quote, turns Auto off, and refuses new paper buys, including strategy buys, until the next Denver day. Sells still work. The breaker also trips by itself when paper equity falls 5% from where it started that Denver day. The Trade panel shows when it tripped and why, and the Signals list shows Breaker as armed or tripped. It works even while a scan or a quote refresh is running.
- **Reset session** starts again on the latest quote and applies the strategy settings.
- **Run full backtest** replays the loaded market history without leaving the latest quote.

The catalog has 7,500 markets: stocks, ETFs, futures, and crypto. Bitcoin, XRP, and Stellar are included. Search the list, or tap a pinned name. Bitcoin, Ether, XRP, Stellar, Solana, and SPY start pinned. Pin keeps the market you are on, and Unpin removes it. The mobile copy remembers the last crypto you opened.

The ticket shows the paper result against the starting cash, plus how many simulated trades have closed and how many of those made money.

The desk is a wide layout on a computer: markets on the left, the daily chart in the center, the paper ticket on the right, and tools along the bottom. The header shows a Paper mark, the symbol, last price, change, and quote time. On an iPhone 14 Plus the same page fits one screen: the price, the change, and the fear clock each keep their own place, and the chart fills the space above the tabs. One line on the phone chart says whether every check is green, and tapping it opens the full Signals list. The phone scan reads three markets at a time, with a short pause after each one, and the ten, the three to five, and the green signals follow the same rule. The chart key stays closed until it is opened. A quote refresh leaves a list alone when that list has not changed. On a phone the same page uses a bottom bar: Markets, Chart, Trade, and Study. The chart draws the latest 180 daily bars so the current price stays readable. The paper replay still uses the full history.

## Edge

Edge is the desk's buy and sell indicator. It matches the Open TMO · Squeeze · CCI chart stack plus a real VIX closed-bar gate. Edge buys at the next bar's open when six checks turn on together on a closed bar: TMO above −10, TMO turns green (main above signal / bullish green paint), five squeeze dots or currently in a squeeze, squeeze momentum above zero, CCI 50 · 14 · 5 all into zone +100 on a closed-bar cross, and VIX falling vs its prior daily close (real ^VIX / .VIX only; fail closed if missing). Ready at 4 of 6, Aim at 5, Fire at 6. Squeeze scan, Fire 5, and Big 3 A+ use the same Fire gates. The starting stop is 2.5 average ranges under that open. While it holds, the stop trails 2.5 average ranges under the best close and never moves down. A close under that stop, or squeeze momentum dropping below zero, sells at the next open.

Earlier Edge settings (5-dot first bar, momentum rising, and an upper Bollinger filter) were tested on two years of real daily bars with 10 basis points each way for the fee and slippage. On BTC, ETH, XRP, XLM, SOL, SPY, QQQ, AAPL, NVDA, MSFT, TSLA, and ES, that older Edge averaged +14.3% while buy-and-hold averaged −2.2%, and it was positive on 10 of those 12. On 20 other markets that were not used to pick the settings, it averaged +28.1% while buy-and-hold averaged +19.3%, and it was positive on 17 of those 20. About one trade in three made money, so most of the gain came from a few large wins. The worst drop averaged about 22% to 25%. That is the past on the prior rule set. The live Edge buy gates now follow TMO · Squeeze · CCI. It is not a forecast.

The Trade panel shows the call (Buy, Hold, Sell, or Wait), which of the five checks are on, the stop and how far price is from it, a 1% risk size from ATR, and the record on this market's past bars: Edge's return, buy-and-hold over the same bars, the worst drop, the number of trades, the share that made money, and the time in the market. Signals use closed bars only. Today's forming bar can still print on the chart, but it does not change the Edge score, the lesson, or the arrows. The chart's clean view draws the candles, paper trades, the Edge stop, the 200-day EMA, and the volume profile. Layers turns VWAP, Bollinger bands, averages, pivots, and lesson arrows on or off. The true momentum panel marks only zero-line crosses after a bar closes. On the phone each Daily scan name also shows its Edge call. B4 readings add the 200 and 50 EMAs, VWAP, POC, MACD, RSI 14, Bollinger, yearly volatility, and ATR size. Edge does not place an order. Trade and Auto keep their own rules.

## Hidden tape

Dark pool books, iceberg orders, and institutional blotters are private. This desk cannot see resting hidden orders and does not invent dark-pool prints.

B4 readings show public-tape proxies from the same real bars and quote the page already loads. Relative volume is the last closed bar versus the prior 20 closed days. Absorption is a high-volume bar whose range stayed tight; initiative is a high-volume bar that traveled. Tape pressure is where that close sat in the bar, plus up versus down volume over the last 20 closed days. Stocks and ETFs on the phone also show the quote feed's 10-day relative volume and after-hours volume when that feed publishes them. Crypto can show the visible bid and ask from the same exchange ticker. A missing field stays blank. These lines do not paint arrows and are not a forecast.

## Timeframes

Ten timeframes sit under the chart: 1 minute, 5 minute, 15 minute, 30 minute, 1 hour, 4 hour, Daily, Weekly, Monthly, and Quarterly. Click one to open it in its own window, or open all ten at once. Each window loads that timeframe's market bars. The Timeframes panel keeps a written brief and a preview. These bars are not a forecast. The center chart stays on the daily session so the paper arrows stay lined up with the trades.

## Study formulas

Open **Study**, paste a formula, and click **Install study**. The formula runs in the page on the quotes already loaded. It is stored on this device. It cannot place a broker order, open a connection, or read files.

A formula can use `input`, `def`, `plot`, `if/then/else`, bar offsets such as `close[1]`, and math such as `Average`, `ExpAverage`, `RSI`, `ATR`, `Highest`, `Lowest`, `Sum`, and `crosses above`. An `AddOrder` line only paints a paper arrow. Fold, profile, and brokerage calls are refused.

## Phone and tablet

The zip contains `iphone/PaperTrader.html`. Opening the computer copy also puts that file in `Documents\iPhone` and opens that folder. That one file is the mobile copy for an iPhone, iPad, Android phone, or other tablet. Install Microsoft Edge from the App Store or the Play Store if it is not already on the device. Copy `Documents\iPhone\PaperTrader.html` onto the phone. On iPhone or iPad, open the Files app, tap the Share button on `PaperTrader.html`, and tap Edge. On Android, open Files or Downloads, choose Open with, and tap Edge. The page cannot switch to Edge by itself. There is no app-store install of this desk and no broker connection.

The mobile file loads live quotes for crypto, stocks, ETFs, and futures, including Bitcoin, Ether, XRP, Stellar, Solana, AAPL, SPY, and ES. Crypto uses the exchange's latest trade. Stocks, ETFs, and futures use the public quote feed's latest trade, including a later after-hours trade when that feed publishes one. The time under the price is when that trade printed. Auto refreshes it. The Type menu stays on the market you pick, and that choice is the list and the scan. Version 1.9.38 asks for that quote the plain way the iPhone allows. That file carries the full catalog so the chart, the fear and greed clock, and the Daily scan can start. Scanner off pauses the phone's walk and keeps names already found. If one live crypto quote does not answer, the page asks the next live crypto feed. If a quote still does not answer, the error is written on the chart and the page does not invent a price. A copied folder loads the chart files that sit beside the page. The computer copy still walks the full catalog through its own quote feed on 127.0.0.1.

## Rules

Long only. A squeeze release with rising momentum opens a simulated position. Momentum turning down closes it. The fast average crossing above the slow average can also open a simulated position when RSI is under 70. A cross back down, RSI at 75 or above, or the stop closes it. The default stop is 8 percent. Set the stop or RSI length to 0 to turn that rule off. The default fee is 5 basis points.

Candles are green when the close is at or above the open, and red when it is below. The chart draws the high, close, and low averages. A red line marks resistance and a green line marks support, with a confirmation line and a dashed risk-off line beside each. Momentum is the lower panel. Dots show squeeze compression. B4 readings list the candle color, squeeze, momentum, price versus those averages, RSI, the fast and slow averages, the pivot prices, true momentum, the lesson, and fear or greed. Green arrows touching a candle are simulated buys. Red arrows touching a candle are simulated sells. Arrows farther from the candle are the lesson: the study setting that matched the next close most often on bars already printed. That score is not a forecast, and it does not place an order. Fear, neutral, or greed says where the last close sits in the recent range of that product. Each market you open gets its own score. The computer scores a book of markets, including the one on the chart, all day and all week while the computer is on and you are signed in to Windows. Closing the desk window does not stop that score, and signing in starts it again. It does not run while the computer is off. While that window is open on wall power, it asks Windows not to sleep, so scoring keeps going all day and all week. The screen can still turn off, and the lock screen still works. On battery, Windows can still sleep. Closing the window ends that request. Zoom in shows fewer bars. Zoom out shows more. The price chart and the study under it zoom together. Each timeframe window has its own zoom.

A **Trade** click fills at the latest quote's close on the paper account.

## Order ticket and local-only lock

Version 1.9.38 adds a broker-style paper order ticket under the Trade buttons: **Buy / Sell**, **Market, Limit, Stop, Stop Limit**, **DAY / GTC**, a **Confirm and Send** box, a **Working orders** table with Cancel and Cancel all, and a price you can type for each leg. Everything is paper.

- A buy uses all paper cash. A sell closes the whole paper position. The ticket has no size box on purpose, because the paper account is one position at a time.
- Market orders fill at the latest real trade plus 5 bps of slippage and the fee, like before.
- A limit waits until the real quote reaches it and never fills worse than its limit.
- A stop becomes a market order when the real quote crosses it. A buy stop must sit above the last price and a sell stop below it, so a stop never fires the moment you place it.
- A stop limit waits for its stop, then follows its limit.
- Working orders are checked on every quote refresh while Auto is on, and when you press Next day. DAY orders expire at the next Denver day. GTC orders stay until filled or canceled.
- **Sell all · Stop buys** and the 5% daily breaker cancel every working order, and the breaker refuses ticket buys until tomorrow. Sells still work.
- **Live** stays locked. No order leaves this computer.

The ticket buys on your own call. The Trade button still follows the scanner's green list.

The desk only answers programs on this computer. It refuses any client that is not 127.0.0.1, any Host that is not 127.0.0.1 or localhost, and any Origin or Referer from another site, so a web page you visit cannot place orders. The launcher files do not run PowerShell, VBS, or Temp installers.

## Artex / foreign-bot isolation (1.9.85)

- Will not start or install from an **Artex** folder (or other foreign-bot path), or from a temporary zip fold.
- Safe check: **Foreign bots kept out**. Paper book, breaker, and learn files stay with this desk only.
- Live stays locked. Every paper buy/sell still asks Yes.

## Tools button · Next pages (1.10.5)

- Header **Tools** button stays on its own grid cell (never clipped beside the title).
- Chart **Next pages** grid sits above the candle stack: Strategies, Internals, Big 3, Journal, and the rest.
- Bottom tab **Tools** opens the same full-screen pages. Live locked · Artex · paper only.

## Market Outlook (1.9.94)

Top-of-desk **Market Outlook** board (own names/copy):

- **Day · Week · Month** from **SPY** closed bars — green / amber / red, score **1–10**, stance **Go long** / **Stay flat** / **Short bias**.
- Best call combines the three horizons. Tide Alert forces **Stay flat · Tide**.
- Long-only desk — **Short bias** means stay flat / pressure review, **no short fills**.
- Guidance only. Edge · Best setup · Auto still gate buys. Paper only. Live locked. Not a crystal ball.

## Lane Align · Range Seat · Week Board (1.9.93)

Original Paper Trader desk processes (own names/copy — not a third-party signal brand). Extends Edge / Fire 5 / Best setup / Journal — **no duplicate scanners**.

- **Lane Align** — top-down index → sector → name confirmation from the Big 3 board. States: Open / Soft / Closed / Unread / Skip. Best setup Auto needs **Lane Open** (or Skip for unmapped/crypto). Fire 5 Auto allows Open or Soft; Unread/Closed fail closed. Desk box + Journal tags.
- **Range Seat** — closed-bar ~52-week seat (High / Mid / Low). Lifts Fire 5 ranking when Seat High. Desk box + Journal tags.
- **Week Board** — Journal strip of this Denver week’s Fire names with Lane · Seat · Tide context. Review only — not a second Fire 5 list.
- Same Edge TMO · Squeeze · CCI · VIX gates. Tide Alert · Go Long 5 · Fire 5 · Big 3 unchanged. Paper only. Live locked. Artex isolation unchanged.

## Tide Alert · Go Long 5 (1.9.92)

Original Paper Trader desk process (own names/copy — not a third-party signal brand):

- **Tide Alert** turns on when **Sector Drain** (no green sector rotation on the Big 3 board) meets **Weekly Tide** (SPY weekly compression with soft structure) or **Index Soft** (majority of indexes not stacked). Closed bars only; **fail closed** when the sector/weekly board is unread.
- Under Tide Alert, day bias becomes **Stay flat · Tide Alert**. Best setup Auto and Fire 5 Auto **hold new Edge longs** (Edge SELL can still exit). Same Edge TMO · Squeeze · CCI · VIX gates stay required for any Fire buy.
- **Go Long 5** ranks up to five pressure names for chart review only when Tide is on (not Fire 5 — Fire 5 is Edge fires). This desk stays **long-only** — no short fills.
- Surfaces in Markets (Tide · Go Long 5) and Big 3 Scorecard. Paper only. Live locked. Artex isolation unchanged.

## Edge VIX gate (1.9.90)

Edge Ready · Aim · Fire is now **six** closed-bar checks. Fire needs all six:

1. TMO above −10  
2. TMO turns green  
3. 5 squeeze dots or in a squeeze  
4. Squeeze momentum above 0  
5. CCI 50 · 14 · 5 into zone +100 (closed-bar cross)  
6. **VIX falling** — latest closed daily VIX close on/before the signal bar is **strictly lower** than the prior daily VIX close (real Yahoo `^VIX` / CNBC `.VIX` only). **Fail closed** if the VIX series is missing.

Ready at **4 of 6**, Aim at **5**, Fire at **6**. Same gates in Squeeze scan, Fire 5, Big 3 A+, Best setup Auto (Edge 6/6 BUY). Chart boxes still paint VIX green/red from the real quote. **TICK / ADD / TRIN / VOLD stay No feed** — will not invent; no TradingView scrape. Paper only. Live locked. Artex isolation unchanged.

## Chart breadth boxes (1.9.89)

Chart-top **TICK / ADD / TRIN / VOLD** stay **No feed**. **VIX** paints from a real Yahoo `^VIX` / CNBC `.VIX` quote. Superseded for Edge gating by 1.9.90.

## Chart breadth boxes (1.9.88)

Fail-closed `/api/breadth` for TICK/ADD/TRIN/VOLD; TradingView path rejected. Superseded for VIX paint by 1.9.89.

## Edge TMO · Squeeze · CCI buys (1.9.87)

Edge five checks now follow the Open TMO · Squeeze · CCI chart stack (closed bars only), tuned on a 40-name Squeeze/Fire-style scan:
1. TMO above −10 (main cleared above the 14/5/3 OS line)
2. TMO turns green (main above signal / bullish green paint on the closed bar)
3. Five squeeze dots or currently in a squeeze
4. Squeeze momentum above zero
5. CCI 50 · 14 · 5 all into zone +100 on a closed-bar cross (mid-14 + cross-into-zone beat mid-20 and state-only on win rate / expectancy without starving)

Squeeze scan, Fire 5, and Big 3 A+ use these same Fire gates. Ready · Aim · Fire, Best setup Auto, Fire 5 Auto, Journal daily check, and boxes-above / charts-below layout stay. Paper only. Live locked. Not a forecast.

## Restore Chart layout (1.9.84)

- Brings back the earlier phone Chart order: boxes → timeframes → price / TMO / Squeeze / CCI.
- Removes sticky chrome that covered the panes when scrolling.
- Second page (Journal, Big 3, Fire 5 docks, etc.) stays below the charts — added without burying them.

## Charts above chrome (1.9.83)

- Earlier attempt moved boxes below charts; superseded by 1.9.84 restore.

## Journal daily check (1.9.82)

- Open **Journal** each day for **Today's check**: buy signals (Fire 5 / today's best), sell / exit signals on open paper longs (Edge exit), and products already filled today.
- Tap a product name to open the chart. No separate sell button — Auto / Trade still ask **Yes** before any paper fill. Paper only. Not a forecast.

## Fire 5 · best trades (1.9.81)

- Daily scan lights up to **five green Fire signals** when Ready · Aim · Fire turns **Fire** on a strong scan name.
- Tap each green name to review the chart, then buy if you want (Confirm still asks).
- **Fire 5 Auto** watches that list and opens a Yes warning before each paper buy. Paper only. Not a forecast.

## Big 3 Market Scorecard (1.9.80)

On the computer desk (Markets card + **Big 3 Scorecard** dock):

- Ranks the strongest indexes and sector funds from closed daily bars (shows ranks as soon as those boards finish).
- Lists A+ squeezes that meet this desk’s strict rules (score 80+, rising bullish momentum, stacked averages, mid/high compression or five+ dots — own math only, not a third-party product).
- Says whether the day favors **swing trades**, **day trades**, or **staying flat** from internals + index stack.
- Shrinks the watchlist, cuts forcing trades, and shows when to size down. Paper only. Not a forecast.

## Bot-on Learning (1.9.79 · QPT-11+)

- **Bot on** = the Paper Trader Learn score process (starts when you open the desk; tick **Start the score** under Windows extras for sign-in).
- While bot on: **every** desk section keeps learning on closed bars even when scrolled away — Markets, Chart, Trade, Study, Strategies, Squeeze scan, Big 3 Scorecard, Internals, Timeframes, big4indicator, Journal, Backtest, Signals.
- **Auto-include:** new dock pages register via `register_desk_page`; new classic strategies via `register_strategy` — the learner picks them up after the next ship without a separate hook.
- **Page open** still refreshes live UI faster.
- Phone/browser alone cannot keep the bot process alive. Paper only. Not a forecast. Not a broker.

## Continuous Learning (1.9.69)

- **Page open:** cycles top Daily scan names, re-scores every strategy on those names, and learns from paper buy/sell fills to refine Ready · Aim · Fire timing.
- **Background (Windows):** the closed-bar scorer keeps running after the desk closes while you are signed in; tick **Start the score** under Windows extras for sign-in. It covers lessons + Daily scan and watches top scan names. Strategy table UI refresh still needs the page.
- Paper only. Closed bars only. Not a forecast. Not a broker.

## Continuous scan Learning (1.9.68)

While the page is open, Learning cycles through the top Daily scan names (green best list, else leaders). Each pass scores closed bars only, two names at a time, and keeps going with Auto refresh. Paper only. Not a forecast.

## big4indicator + Ready · Aim · Fire (1.9.67)

- **big4indicator** colors candles all green in a bullish stretch and all red in a bearish stretch (mixed gray). Toggle in Layers.
- **Ready · Aim · Fire** is this desk's Edge staging (not a third-party product): Ready at 3 checks, Aim at 4, Fire when all five turn on. BUY/SELL arrows paint only at Fire (next open). Auto buy waits for Fire and prefers bullish big4indicator.

## Solid candle colors (1.9.66)

Up candles are solid green and down candles are solid red, including the wicks, so the price pane stays easy to read over the overlays.

## Clear chart overlays (1.9.65)

Price chart shows **large BUY / SELL arrows** from Edge only: closed-bar signal, fill at the next open, past arrows never move. Support and resistance boxes, green trend EMA 50, VWAP line, and a clear chip row for VWAP D/W/M, Desk B4 bias, Bollinger %B(20), and stage. Lesson arrows stay off unless you turn that layer on. Public closed-bar math only. Not a forecast.

## Study spacing (1.9.64)

Price, TMO, Squeeze, and CCI are separate boxes one under another (not overlapping). Scroll the chart to see each full pane. **Open TMO · Squeeze · CCI** still opens a full window. Compact studies tightens heights if you want more on screen at once.

## Study rollup and window (1.9.63)

On computer and phone, each study pane has a **▾ / ▸** rollup arrow. **Expand studies** makes TMO, squeeze, and CCI taller. **Open TMO · Squeeze · CCI** (and each pane’s Open ▢) opens the three studies in a separate window so you can see the full oscillators while the main desk stays open. Chart area scrolls so the four panes are not crushed into tiny squares.

## TOS-style study panes (1.9.62)

The chart stacks four panes like a desk layout: price with the SMA stack, then **true momentum (TMO 14/5/3)** with a cyan readout banner and cyan/pink cross arrows, then **squeeze momentum** as its own cyan/blue/yellow/red histogram with compression dots, then **CCI 50 / 14 / 5** in white/yellow/cyan with ±100 lines and green/red arrows on closed-bar crosses. Status chips above the chart show trend, breakdown/breakout, squeeze alert, Edge, momentum, and VWAP from closed bars. Public closed-bar math only — not a third-party or trademarked study. Not a forecast.

## Best setup Auto (1.9.61)

**Best setup Auto** on Strategies arms the strictest paper-buy gate and shows a live gate checklist. With Auto and strategy follow on, it only offers an Edge buy when all of these are green on closed bars: Edge 5/5 BUY, most timeframes buying or holding (at least two-thirds), internals Supportive (or Mixed 55+ with more good than bad), SMA stack lined up, weekly and monthly multi-TF on, the open market in today’s green scan list, a fresh quote, not extreme greed (fear/greed under 85), and fewer than three new paper buys that Denver day. Arming it loads timeframes and internals and turns the internals gate on. Edge SELL can still exit a long. Voice can announce **Best setup ready**. The second warning still asks Yes. Green **Best setup** signal lights when every gate is ready. Not a forecast.

## Best setup Auto (1.9.60)

First Best setup Auto release: Edge all-five, multi-TF majority, supportive internals, scan list, max three buys, button and green signal.

## Squeeze · TMO · B4 · stack · MTF (1.9.59)

The four-study combo now also needs **multi-timeframe agreement**: completed weekly and monthly bars must show true momentum above its signal and close above that frame's 20-bar EMA. Daily legs stay the desk's squeeze release, TMO, B4 trend, and SMA stack (5>9>21>50). This desk's own closed-bar math only — not a third-party or trademarked study. Past bars only. Not a forecast.

## Edge five-check tune (1.9.58)

Edge still needs all five checks on a closed bar, then buys the next open. The squeeze-dot check now fires only on the first bar that reaches exactly five dots (not every later day still in the squeeze), and the trail uses 2.5 ATR under the best close. Same public closed-bar pieces, 10 bps each way, no look-ahead. Past bars only — not a forecast.

## Strategies board layout (1.9.57)

Every Strategies row — Edge through the four-study combo, CCI zoom, CCI snap-back, and the rest — uses the same columns: Strategy, Now, Trades, Wins, Result, Hold, Worst trade. WAIT pills and numeric columns stay aligned with the classic closed-bar ranking table.

## CCI zoom and snap-back (1.9.56)

Strategies adds **CCI zoom zone** and **CCI snap-back** right under the four-study combo. Zoom up buys when CCI(50) crosses above +100 and exits when it falls back under +100. Snap-back up buys when, while still in zoom up, CCI(5) was more than 150 points under CCI(50) and that gap then closes. Exit on a snap-back down fire or leaving zoom up. Zoom down is shown for context; this long-only desk does not short. Classic public CCI rules. Not a forecast.

## Four-study combo on Strategies (1.9.55)

Strategies lists **Squeeze · TMO · B4 · stack · MTF** third on the board (under Squeeze release): this desk's squeeze release, true momentum above signal, B4 trend (close above 50/200 EMAs, MACD above signal, RSI under 70), the SMA stack lined up 5 over 9 over 21 over 50, and completed weekly plus monthly agreement — all closed-bar. Stop under that bar's low. Exit on a TMO cross down or a close under the 50 EMA. Own closed-bar math only. Not a forecast.

## Strategies Buy and Sell (1.9.53)

After you pick the best strategy on the Strategies tab, **Buy** and **Sell** place a paper trade on the open market through the same second warning. Buy is for a flat book; Sell closes an open paper long. The lineup still shows whether that strategy agrees. Paper only.

## Ten classic strategies and desk triggers (1.9.52)

The Strategies tab now scores ten classic public closed-bar rules on this market’s history: Edge, squeeze release, 20-day breakout, RSI 2 pullback, 50/200 average cross, 20/50 EMA cross, MACD cross, Bollinger reversion, EMA trend with an ATR trail, and the 7-day low pullback. Auto can still follow the one you pick. Desk triggers (Voice) cover squeeze five dots/steam, Edge BUY on pinned markets, the followed strategy’s BUY/SELL, and a new process. Closed bars only. Not a forecast. None of these is a third-party or trademarked system.

## New process green signal (1.9.51)

When the closed-bar scorer finds a better process for a market, the desk lights a green **New process** signal, stamps that process on the market’s paper fills, and keeps updating those fills as learning continues. Tab clicks and strategy tests still feed the learn book. Closed bars only. Not a forecast.

## Learn on every tab click (1.9.50)

Opening Study tabs (Strategies, Squeeze, Journal, Backtest, and the rest), phone tabs, or a strategy row scores the open market’s closed bars into the learn book right away and prioritizes it for the all-day scorer. Strategy list runs feed those markets into the watch list too. Still closed bars only. Not a forecast.

## Professional desk chrome (1.9.49)

Live quote age sits under the last price and softens when the quote is stale. The chart shows an open-position chip, a scrub readout as you move across candles, and a status rail on the phone. The order ticket previews size and cost before Send. Journal has a today strip for fills and closed P/L. The dock tab you last opened is remembered. On the computer, keyboard shortcuts set Buy/Sell (B/S), order type (1–4), Journal (J), Chart (C), and Search (/). Load paper book works both ways: phone to computer and computer to phone.

## Share the paper book with the phone (1.9.48)

The computer desk and the phone each keep their own paper book. Under Journal, **Share paper book** downloads `paper-book.json` with every open position and working limit or stop order. On the phone, open Journal and **Load paper book**, then pick that file. Copy paper book puts the same JSON on the clipboard when the browser allows it. Load on the computer merges that file back into this computer's shelf.

## Chart candles, SMA stack, and true momentum (1.9.47)

Price candles are hollow on up bars and solid on down bars. A layer draws simple averages 5, 9, 21, 50, 100, and 200 on the chart's own bars. The lower panel is this desk's true momentum (14/5/3) with a Main/Signal cloud and arrows that mark crosses only after the bar closes. No third-party study source is included.

## Squeeze lists, journal orders, and chart Back (1.9.46)

The squeeze scan has separate lists for all stocks, the 13 main ETFs, all futures, and all crypto in this desk's catalog. Names still appear as each market comes back. The Journal tab lists working limit, stop, and stop-limit paper orders for every market next to open positions and fills. Chart and timeframe windows have a Back button. This desk's squeeze uses its own high, mid, and low compression levels. It is not a third-party study and does not use third-party source.

## Squeeze scan (1.9.45)

The squeeze scan lists a market as soon as that market's daily bars come back, instead of waiting until the whole list is finished. While it is running, the daily scan, internals, and timeframe reads wait, so the squeeze scan is not stuck behind them. Each read is still one quote at a time. A feed that does not answer is skipped for the rest of that scan.

## Phone page (1.9.44)

Popup windows for a timeframe or the brief are filled with plain text, so a market name cannot become markup. Quote reads, including the daily scan, the squeeze scan, a strategy list, and the timeframe reads, go one at a time with a pause between them. The web address serves one page. The saved file for Files and Edge stays in the Windows zip only.

## Phone page (1.9.43)

The iPhone copy is one web page. Open it from its web address in Safari. A link on github.com, including the raw file link, is sent as plain text, so the phone shows the code and the desk never starts. Saving PaperTrader.html and opening it from Files, then Share, then Edge, still works.

## Edge on every timeframe, the price box, and BUY/SELL tags (1.9.42)

**Edge reads all ten timeframes.** Under the Edge box, a row of chips shows Edge's call on 1m, 5m, 15m, 30m, 1h, 4h, daily, weekly, monthly, and quarterly, each read from that timeframe's own closed bars. The Timeframes tab has the same list as a table with checks, stop, past trades, win rate, and result. Click a row to put that timeframe in the preview. A timeframe with fewer than 52 bars shows a dash instead of a guess. The summary line says how many timeframes are buying or holding, selling, or waiting. The second-warning window lists that count as a line-up item. Auto and the strategies still read the daily bars only. The preview and every timeframe window also draw the Edge stop line and Edge buy and sell dots, and say Edge's current call.

**BUY and SELL on the second chart.** The lower study chart now carries labeled BUY and SELL tags at the same bars as Edge's green and red dots on the price chart, with a faint line down the chart, and its title shows Edge's current call. The Timeframes preview and every timeframe window show the same tags on their lower panel.

**Price box.** Click any candle on the main chart, the lower study, the Timeframes preview, or any timeframe window and a box shows the date and time, open, high, low, close, change from the bar before, range, volume, and how many of Edge's five checks were on for that bar and which were missing. A dashed line marks the bar. Close the box with the x or Escape.

## Second warning and strategy testing (1.9.40)

**Every buy and sell asks twice.** Pressing Trade, Send on the ticket, Sell all, or arming an opening-bar order opens a window that says what will happen, the market, the latest quote, your paper cash and shares, who started it, and a line-up list: Paper only, Safe check, Circuit breaker (buys), Internals (buys), and whether the chosen strategy agrees. A STOP line (paper is off, the Safe check failed, the breaker is on) disables the Yes button. No is the default, and Escape or a click outside also cancels. The desk itself refuses a buy or sell that does not carry the confirmation, so nothing, not even a script, can trade without it.

**Auto signals ask too.** When the strategy you picked gives a fresh buy or sell on a closed bar, the same window opens and nothing trades until you press Yes. Pressing No skips that signal for good. When you press Yes the desk checks the signal is still on, and if it is not, nothing trades. Working limit and stop orders were approved when you placed them, and that OK covers their later fill. The circuit breaker is the one automatic sell kept on purpose: a 5% daily paper drop sells everything to cash and stops buys until tomorrow.

**Click a strategy to test it.** In the Strategies tab, click any strategy row. A panel shows that strategy's own past trades on the market you are on (dates, entry, exit, result, why it closed). Press Run on the list to run it on a list of markets from the starter, sector, crypto, or futures lists, ranked by result, and click a market in that list to open it. It reads real daily bars and places nothing. These are past closed bars, not a forecast.

## Quiet installer (1.9.39)

Security programs watch for programs that end other programs, delete folders they did not make, or write sign-in files without asking. This copy does none of those. The installer never ends another program and never deletes another folder. When a Paper Trader Learn window from an older copy is open, it leaves a small request file and that window closes itself. Other copies are listed in the Safe check as a note. The sign-in file and the Desktop file made by the desk are off until you tick them under Windows extras in the Safe check, and each can be removed by unticking. The Safe check item Quiet installer scans this program's own files for calls that end programs, edit the registry, or schedule tasks.

## Journal, Safe check, Strategies, and Squeeze scan (1.9.39)

**Journal.** Every market keeps its own paper account. Switching markets no longer drops an open position. The Journal tab now lists **Open positions** across every market, **Every fill** with its Denver time and why it happened (your trade, a ticket, a working order, Sell all, or Auto), and **Closed trades**. On the computer the book is saved next to the journal. On the phone page it is saved in that browser's storage. Press **Reset session** to wipe only the market you are on. On the computer, a position the history replay opened is labeled "History replay" instead of "Your fill or Auto".

**Safe check.** The green button under Sell all runs these safety checks, and again every minute: the desk listens on 127.0.0.1 only, other computers and other web pages are refused, Live is locked, quotes come from the one allowed feed host, the circuit breaker is readable, the order rules pass a built-in test (limit, stop, market, and a buy then sell round trip), the journal can write and read back, the program files are the same as when it opened, the launcher files contain nothing that runs scripts or changes Defender, and only one copy is installed. Any failed safety item turns the button red and stops Auto. Quote and learning status only turn it amber. Green means those checks passed at that moment. It does not mean a market will go up.

**Strategies tab.** Four strategies read closed bars only and are scored on the market you are on: Edge, a squeeze release (Bollinger Bands back outside Keltner Channels with momentum rising, stop under that bar), a 20-bar range breakout, and a short RSI pullback in an uptrend. The table shows what each says now, its past trades, win rate, result against holding, and its worst trade, and marks the best past result once a strategy has five trades. That ranking looks backward and picking the winner after the fact flatters it. **Auto follows** lets Auto place paper trades from the strategy you pick, once per closed-bar signal, through the same scanner rules and circuit breaker. A 15-minute opening bar panel reads the real 15-minute bars, shows the buy stop above the first bar's high, the protective stop at its low, and a target, and can arm those as working paper orders. This desk is long only, so a break below the low is shown as a bearish break and no short is opened.

**Squeeze scan tab.** Reads real daily bars for a list (starter list, sector funds and big holdings, crypto, futures, or your own) and ranks the squeezes. Points go to a squeeze that is on or just fired, more bars of built-up energy, a tight squeeze, moving averages (8, 21, 50) stacked with momentum, a clean squeeze where momentum never crossed zero, momentum building, a weekly squeeze too, and the same squeeze in a stock, its sector fund, and its index fund. Names that are not in this bot's market list are skipped and listed, never guessed. Each row opens that market.

**Internals tab.** Reads the fear gauges (VIX, 9-day VIX, VXN), SPY and QQQ trend, how many of the ten sector funds sit above their 21-day average, equal weight against cap weight, small against large, offense against defense, credit (HYG against IEF), the 10-year yield, and the dollar, all from real closed daily bars, and rolls them into Supportive, Mixed, or Defensive with the reason for every point. A pill under the Trade buttons shows it everywhere. **Respect internals** (on by default) makes Auto skip new buys in stocks, ETFs, and futures while internals are Defensive. Sells are never blocked, crypto is not gated, and a gauge that does not answer is listed as not read, never guessed. NYSE TICK, ADD, TRIN, and VOLD stay No feed (see Chart breadth boxes 1.9.88). The Safe check lists internals as a health item.

**Where this comes from.** All code and wording here is original. The math is general and public: Bollinger Bands, Keltner Channels, moving averages, RSI, price ranges, and opening ranges. No vendor's indicator code, scripts, scoring, text, logos, or product names were copied or used, and this project has no affiliation with any trading education company or broker. The point values in the scan are this project's own choices, not anyone else's formula.

Markets: all 7,510 from the catalog (crypto including XRP and Stellar, stocks, ETFs, and futures). Added in 1.9.38: VXUS, QQQM, SCHD, SCHG, VUG, and QUAL, so the core ETF list (VOO, VTI, VXUS, QQQM, SCHD) and the growth list (SMH, XLK, VGT, QQQ, IVW, SCHG, IWF, VUG, QUAL, IJH) are all searchable.

## Schwab connect (1.10.4)

Paper stays the default. The desk does not send broker orders. Quotes still use the existing feed until Schwab bars are wired; **Connect**, **Market Data**, and **Live Trading** prepare the Schwab session. Panels use a steel-desk palette (charcoal / slate / mint / coral / ice) so status colors stay clear without glow spam. Connect + Outlook share one compact top rail so charts keep the room. A big **Tools** button sits beside the Paper Trader title. Study, Strategies, Squeeze scan, Scorecard, Internals, Timeframes, big4indicator, Journal, Backtest, and Signals open as full Tools pages with Back.

When the Schwab Developer Portal app (`personal-market-data`, Market Data Production, callback `https://127.0.0.1`) is approved:

1. Open **`Documents\Paper Trader\.env`** (created automatically on install/launch from `SCHWAB-KEYS.txt` / `.env.example` if missing). You can also open `SCHWAB-KEYS.txt` in that folder — same placeholders.
2. Paste your App Key and App Secret over the placeholders:

```
SCHWAB_APP_KEY=paste-app-key-here
SCHWAB_APP_SECRET=paste-app-secret-here
SCHWAB_CALLBACK_URL=https://127.0.0.1
SCHWAB_APP_NAME=personal-market-data
```

3. Never commit `.env` or `schwab_tokens.json`. Reinstalls keep both in place.
4. At the **top of the desk**, **Connect to Schwab** sits with a green/red light (CONNECTED / NOT CONNECTED). It opens Schwab sign-in; paste the `https://127.0.0.1/?code=...` redirect URL to finish. Tokens stay in `schwab_tokens.json`.
5. On the Trade panel: **Market Data** (after Connect) and **Live Trading** (after Market Data; confirm; default off). Paper remains the default; no broker orders.
6. **Signals** also show **Schwab** green/red. CLI: `python -m paper_trader schwab-status`.

## Check

```bash
cd paper-trader
python -m unittest discover -s tests -v
python -m paper_trader backtest --symbol BTC-USD
```
