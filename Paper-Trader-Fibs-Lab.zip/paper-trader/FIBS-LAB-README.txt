Paper Trader Fibs Lab 1.10.73
Extract All → open paper-trader\Start-Fibs-Lab.bat
Lands in Documents\PaperTrader-Fibs-Lab (separate from your working desk).
Desktop shortcut: Paper Trader Fibs Lab.bat
Port 8787. Never overwrites Paper Trader.bat or Documents\Paper Trader.
