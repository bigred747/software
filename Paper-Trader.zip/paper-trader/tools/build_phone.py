"""Build the single-file mobile page. It runs in Microsoft Edge with no server and no broker."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build() -> Path:
    web = ROOT / "web"
    html = (web / "index.html").read_text(encoding="utf-8")
    css = (web / "app.css").read_text(encoding="utf-8")
    style = "<style>\n" + css + "\n</style>"
    html = html.replace('<link rel="stylesheet" href="/app.css">', style)
    html = html.replace('<link rel="stylesheet" href="app.css">', style)
    raw = (ROOT / "paper_trader" / "catalog.txt").read_text(encoding="utf-8")
    lines = [line for line in raw.splitlines() if line.endswith(("\tcrypto", "\tstock", "\tetf", "\tfuture"))]
    if sum(line.endswith("\tcrypto") for line in lines) < 5:
        raise RuntimeError("crypto catalog is empty")
    if not any(line.endswith("\tstock") for line in lines):
        raise RuntimeError("stock catalog is empty")
    if not any(line.endswith("\tetf") for line in lines):
        raise RuntimeError("etf catalog is empty")
    if not any(line.endswith("\tfuture") for line in lines):
        raise RuntimeError("futures catalog is empty")
    catalog = "\n".join(lines) + "\n"
    live = (web / "live.js").read_text(encoding="utf-8")
    engine = (web / "engine.js").read_text(encoding="utf-8")
    study = (web / "study.js").read_text(encoding="utf-8")
    frames = (web / "frames.js").read_text(encoding="utf-8")
    app = (web / "app.js").read_text(encoding="utf-8")

    def inline(page: str, name: str, body: str) -> str:
        block = "<script>\n" + body + "\n</script>"
        page = page.replace(f'<script src="/{name}"></script>', block)
        return page.replace(f'<script src="{name}"></script>', block)

    html = inline(html, "live.js", live)
    catalog_script = "<script>globalThis.PAPER_CATALOG = " + json.dumps(catalog) + ";</script>\n"
    html = html.replace('<script src="/engine.js"></script>', catalog_script + "<script>\n" + engine + "\n</script>")
    html = html.replace('<script src="engine.js"></script>', catalog_script + "<script>\n" + engine + "\n</script>")
    html = inline(html, "study.js", study)
    html = inline(html, "frames.js", frames)
    html = inline(html, "app.js", app)
    for name in ("live.js", "engine.js", "study.js", "frames.js", "app.js", "app.css"):
        if f'src="/{name}"' in html or f'src="{name}"' in html or f'href="/{name}"' in html or f'href="{name}"' in html:
            raise RuntimeError(f"{name} was not inlined")
    folder = ROOT / "iphone"
    folder.mkdir(exist_ok=True)
    out = folder / "PaperTrader.html"
    out.write_text(html, encoding="utf-8")
    (folder / "index.html").write_text(html, encoding="utf-8")
    (folder / "icon.png").write_bytes((web / "icon.png").read_bytes())
    (folder / "manifest.webmanifest").write_text((web / "manifest.webmanifest").read_text(encoding="utf-8"), encoding="utf-8")
    note = folder / "README.txt"
    note.write_text(
        "\n".join(
            [
                "Paper Trader on a phone or tablet",
                "",
                "1. On iPhone, open the Paper Trader web address in Safari. Tap Share, then Add to Home Screen so the desk opens like an app and you stay signed in. A github.com link shows the file as code and does not run it.",
                "2. To keep a copy on the phone, save PaperTrader.html. If it arrives as a text file, rename it to PaperTrader.html.",
                "3. Open the Files app, tap the Share button on PaperTrader.html, then tap Edge.",
                "4. On Android or another phone or tablet, open Files or Downloads, tap PaperTrader.html, choose Open with, then tap Edge.",
                "5. The desk runs in Edge or Safari. The chart, the fear and greed clock, and the Daily scan use live quotes. Crypto uses the exchanges. Stocks, ETFs, and futures use the public quote feed. The Type choice stays on Stocks, ETFs, Futures, or Crypto. If a quote does not answer, that error is written on the chart and the page does not invent a price.",
                "6. Nothing is sent to a broker. This desk is not an app-store app. The page cannot switch to Edge by itself.",
                "",
                "The computer copy is started with Start-Paper-Trader.bat and opens in Microsoft Edge on 127.0.0.1.",
                "That computer keeps scoring after the Paper Trader window closes. It runs while the computer is on and you are signed in. Starting it at sign-in is optional, under Windows extras in the computer's Safe check.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return out


if __name__ == "__main__":
    path = build()
    print(path, path.stat().st_size)
