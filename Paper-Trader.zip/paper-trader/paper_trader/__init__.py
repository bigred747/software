"""Local paper trading desk. Sample prices only. No broker orders."""

__version__ = "1.8.0"
