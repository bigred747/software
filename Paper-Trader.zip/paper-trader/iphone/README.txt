Paper Trader on a phone or tablet

1. Install Microsoft Edge if it is not already on the device. Use the App Store on iPhone or iPad, or the Play Store on Android.
2. Copy PaperTrader.html onto the device. If it arrives as a text file, rename it to PaperTrader.html.
3. On iPhone or iPad, open the Files app, tap the Share button on PaperTrader.html, then tap Edge.
4. On Android or another phone or tablet, open Files or Downloads, tap PaperTrader.html, choose Open with, then tap Edge.
5. The desk runs in Edge. Crypto quotes are live. Stocks, ETFs, and futures load on the computer copy.
6. Nothing is sent to a broker. This desk is not an app-store app. The page cannot switch to Edge by itself.

The computer copy is started with Start-Paper-Trader.bat and opens in Microsoft Edge on 127.0.0.1.
That computer keeps scoring after the Paper Trader window closes. It starts again when you sign in to Windows, while the computer is on and you are signed in.
